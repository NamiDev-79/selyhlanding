"use client";

import { useState } from "react";

import { Button, LinkButton } from "@/components/ui/button";
import { Empty, Loading, Notice } from "@/components/ui/feedback";
import { TrendChart } from "@/components/ui/trend-chart";
import { companyCopy, metricCopy } from "@/content/company";
import { api, errorText, type Res, unwrap } from "@/lib/api/client";

import { useCompany, useCompanyMutation, useTeamMetrics, useTeams } from "./hooks";

type Metric = Res<"/companies/{companyId}/teams/{teamId}/metrics", "get">[number];
const MIN_K = 5;

function latestBy(rows: Metric[]) {
  const out = new Map<string, Metric>();
  for (const r of rows) if (!out.has(r.metricKey)) out.set(r.metricKey, r); // vienen del más reciente al más antiguo
  return out;
}

function TeamBlock({ team, k }: { team: { id: string; name: string }; k: number }) {
  const { companyId } = useCompany();
  const metrics = useTeamMetrics(companyId, team.id);
  const [skipped, setSkipped] = useState<string | null>(null);
  const refresh = useCompanyMutation(companyId, () =>
    unwrap(api.POST("/companies/{companyId}/teams/{teamId}/aggregate", { params: { path: { companyId, teamId: team.id } } })),
  );

  const rows = metrics.data ?? [];
  const latest = latestBy(rows);
  const stress = rows.filter((r) => r.metricKey === "stress_zscore").reverse();

  return (
    <article className="grid gap-5 border-t border-ink pt-6">
      <header className="flex flex-wrap items-baseline justify-between gap-4">
        <h2 className="text-step-3">{team.name}</h2>
        <Button
          size="sm"
          variant="ghost"
          pending={refresh.isPending}
          onClick={() => refresh.mutate(undefined, { onSuccess: (r) => setSkipped(r.written ? null : (r.skippedReason ?? companyCopy.noData(k))) })}
        >
          Recalcular
        </Button>
      </header>

      {metrics.isPending ? <Loading /> : null}
      {metrics.isError ? <Notice tone="attention" title={errorText(metrics.error)} /> : null}
      {skipped ? <Notice tone="neutral" title={`Sin publicar: ${skipped}.`}>Por privacidad no mostramos nada por debajo del mínimo.</Notice> : null}
      {refresh.isError ? <Notice tone="attention" title={errorText(refresh.error)} /> : null}

      {metrics.data && !rows.length ? (
        <p className="flex items-start gap-3 border border-dashed border-line-strong px-4 py-3 text-ink-soft">
          <span aria-hidden className="figures mt-0.5 text-xs text-ink-faint">
            k&lt;{k}
          </span>
          {companyCopy.noData(k)}
        </p>
      ) : null}

      {latest.size ? (
        <dl className="grid gap-x-10 gap-y-5 sm:grid-cols-3">
          {["stress_zscore", "checkin_score", "high_load_share"].map((key) => {
            const m = latest.get(key);
            const copy = metricCopy[key]!;
            return (
              <div key={key} className="grid content-start gap-1">
                <dt className="text-step--1 text-ink-soft">{copy.label}</dt>
                <dd className="font-display text-step-2">{m ? copy.describe(m.value) : "—"}</dd>
                {m ? (
                  <dd className="figures text-[11px] text-ink-faint">
                    {key === "high_load_share" ? `${Math.round(m.value * 100)}%` : m.value.toFixed(2)} · n={m.sampleSize}
                  </dd>
                ) : null}
              </div>
            );
          })}
        </dl>
      ) : null}

      {stress.length > 1 ? (
        <TrendChart values={stress.map((s) => s.value)} labels={["primer periodo", "último"]} bandLabel="rango habitual del equipo" ariaLabel={`Tendencia agregada de carga del equipo ${team.name}.`} height={180} />
      ) : null}
    </article>
  );
}

export function CompanyOverview() {
  const company = useCompany();
  const teams = useTeams(company.companyId);
  const k = Math.max(MIN_K, company.minAggregationSize ?? MIN_K);

  return (
    <div className="grid gap-12">
      <p className="max-w-[68ch] border-l-2 border-accent pl-4 text-ink-soft">{companyCopy.privacyNote(k)}</p>
      {teams.isPending ? <Loading /> : null}
      {teams.isError ? <Notice tone="attention" title={errorText(teams.error)} /> : null}
      {teams.data && !teams.data.length ? (
        <Empty title="Aún no hay equipos">
          <p>Crea tus equipos y asigna a las personas para empezar a ver tendencias.</p>
          <LinkButton href="/empresa/equipos" size="sm" variant="secondary" className="mt-3">
            Crear un equipo
          </LinkButton>
        </Empty>
      ) : null}
      {teams.data?.map((t) => (
        <TeamBlock key={t.id} team={t} k={k} />
      ))}
      {teams.data?.length ? <p className="text-step--1 text-ink-faint">{companyCopy.causes}</p> : null}
    </div>
  );
}

"use client";

import { ArrowRight } from "lucide-react";
import Link from "next/link";

import { AnimatedLogo } from "@/components/brand/animated-logo";
import { Button } from "@/components/shadcn/button";
import { finalCta } from "@/content/landing";

import { Reveal, Wrap } from "./primitives";

/**
 * Cierre: el logo hace su entrada (la pausa llega primero) y la frase de marca en Lora.
 * Es el único lugar de la página donde aparece la animación completa con respiración.
 */
export function FinalCta() {
  return (
    <section aria-labelledby="cierre-title" className="py-[clamp(4.5rem,3rem+6vw,8rem)]">
      <Wrap className="grid justify-items-center text-center">
        <AnimatedLogo className="h-[clamp(3.5rem,2.5rem+4vw,6.5rem)] text-foreground" title="Selyh" />
        <Reveal className="mt-10 grid justify-items-center gap-[26px]">
          <p className="quote text-[clamp(1.5rem,1.1rem+1.6vw,2.25rem)] leading-[1.3] text-brand-display">Prevenir también es parte del trabajo.</p>
          <h2 id="cierre-title" className="max-w-[20ch] font-display text-[clamp(1.75rem,1.2rem+2.2vw,2.625rem)] leading-[1.1]">
            {finalCta.title}
          </h2>
          <p className="max-w-[52ch] text-[1.0625rem] leading-[1.65] text-muted-foreground">{finalCta.body}</p>
          <div className="flex flex-wrap justify-center gap-2.5">
            <Button asChild size="lg">
              <Link href={finalCta.primary.href}>
                {finalCta.primary.label}
                <ArrowRight aria-hidden />
              </Link>
            </Button>
            <Button asChild size="lg" variant="ghost">
              <Link href={finalCta.secondary.href}>{finalCta.secondary.label}</Link>
            </Button>
          </div>
        </Reveal>
      </Wrap>
    </section>
  );
}

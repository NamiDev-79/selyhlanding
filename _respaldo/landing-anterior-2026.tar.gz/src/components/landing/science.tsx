"use client";

import { motion } from "motion/react";
import Link from "next/link";

import { science } from "@/content/landing";

import { EASE, Eyebrow, Reveal, SectionTitle, Wrap } from "./primitives";

/** Respaldo científico: qué usamos, explicado sin jerga, y lo que Selyh no es. */
export function Science() {
  return (
    <section aria-labelledby="ciencia-title" className="border-t border-border py-[clamp(4.5rem,3rem+5vw,7rem)]">
      <Wrap className="grid gap-14 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.618fr)] lg:gap-[68px]">
        <Reveal className="grid content-start gap-[26px]">
          <Eyebrow n="06">{science.eyebrow}</Eyebrow>
          <SectionTitle id="ciencia-title">{science.title}</SectionTitle>
          <p className="max-w-[48ch] text-[1.0625rem] leading-[1.65] text-muted-foreground">{science.intro}</p>
          <p className="max-w-[40ch] text-[0.9375rem] text-muted-foreground">
            El nombre rinde homenaje a{" "}
            <Link href="/hans-selye" className="quote text-[1.0625rem] text-foreground underline decoration-brand-soft decoration-1 underline-offset-4 hover:decoration-current">
              Hans Selye
            </Link>
            , pionero del estudio científico del estrés.
          </p>
        </Reveal>

        <div className="grid content-start gap-10">
          <dl className="grid gap-x-10 sm:grid-cols-2">
            {science.items.map((it, i) => (
              <motion.div
                key={it.term}
                initial={{ opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.5 }}
                transition={{ duration: 0.55, ease: EASE, delay: i * 0.05 }}
                className="grid content-start gap-1.5 border-t border-border py-5"
              >
                <dt className="font-display text-[1.0625rem] font-bold">{it.term}</dt>
                <dd className="text-[0.9375rem] leading-relaxed text-muted-foreground">{it.body}</dd>
              </motion.div>
            ))}
          </dl>

          <Reveal>
            <aside aria-labelledby="limites-title" className="grid gap-3 rounded-2xl bg-brand-tint p-[26px]">
              <h3 id="limites-title" className="font-display text-xl font-bold">
                {science.limits.title}
              </h3>
              <p className="text-[0.9375rem] leading-relaxed text-foreground/80">{science.limits.body}</p>
            </aside>
          </Reveal>
        </div>
      </Wrap>
    </section>
  );
}

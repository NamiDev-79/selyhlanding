"use client";

import { useState } from "react";

import { Section } from "@/components/layout/app-shell";
import { Button } from "@/components/ui/button";
import { Badge, Empty, Loading, Notice } from "@/components/ui/feedback";
import { Input, Select } from "@/components/ui/field";
import { companyCopy } from "@/content/company";
import { api, errorText, unwrap } from "@/lib/api/client";
import { SimulatedNotice } from "@/features/onboarding/plan-picker";
import { usePlans } from "@/features/onboarding/hooks";

import { useAudit, useCompany, useCompanyMutation, useInvites, useMembers, useSeats, useTeams } from "./hooks";

const fmt = (iso: string) => new Date(iso).toLocaleString("es-PE", { dateStyle: "medium", timeStyle: "short" });

// ───────────────────────────── Equipos ─────────────────────────────

export function TeamsManager() {
  const { companyId } = useCompany();
  const teams = useTeams(companyId);
  const members = useMembers(companyId);
  const [name, setName] = useState("");
  const [assign, setAssign] = useState<Record<string, string>>({});
  const [assigned, setAssigned] = useState<string | null>(null);
  const create = useCompanyMutation(companyId, (n: string) => unwrap(api.POST("/companies/{companyId}/teams", { params: { path: { companyId } }, body: { name: n } })));
  const add = useCompanyMutation(companyId, ({ teamId, userId }: { teamId: string; userId: string }) =>
    unwrap(api.POST("/companies/{companyId}/teams/{teamId}/members", { params: { path: { companyId, teamId } }, body: { userId } })),
  );

  return (
    <div className="grid gap-14">
      <Section title="Nuevo equipo" description="Agrupa como trabajan de verdad: por producto, guardia o área.">
        <form
          className="flex flex-wrap items-end gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            create.mutate(name.trim(), { onSuccess: () => setName("") });
          }}
        >
          <Input label="Nombre del equipo" value={name} onChange={(e) => setName(e.target.value)} className="w-72" />
          <Button type="submit" disabled={name.trim().length < 2} pending={create.isPending}>
            Crear equipo
          </Button>
        </form>
        {create.isError ? <Notice tone="attention" title={errorText(create.error)} /> : null}
      </Section>

      <Section title="Equipos" description={`Recuerda: con menos de 5 personas un equipo no mostrará tendencias.`}>
        {teams.isPending ? <Loading /> : null}
        {teams.data && !teams.data.length ? <Empty title="Aún no hay equipos">Crea el primero arriba.</Empty> : null}
        <ul className="grid border-t border-line">
          {teams.data?.map((t) => (
            <li key={t.id} className="grid gap-3 border-b border-line py-5 sm:grid-cols-[1fr_auto] sm:items-end">
              <div className="grid gap-0.5">
                <span className="font-display text-step-2">{t.name}</span>
                <span className="figures text-xs text-ink-faint">creado {fmt(t.createdAt)}</span>
              </div>
              <form
                className="flex flex-wrap items-end gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  const userId = assign[t.id];
                  if (userId)
                    add.mutate(
                      { teamId: t.id, userId },
                      {
                        onSuccess: () => {
                          setAssigned(t.id);
                          setAssign({ ...assign, [t.id]: "" });
                        },
                      },
                    );
                }}
              >
                <Select label="Asignar persona" value={assign[t.id] ?? ""} onChange={(e) => setAssign({ ...assign, [t.id]: e.target.value })} className="w-60">
                  <option value="">Elegir…</option>
                  {members.data?.map((m) => (
                    <option key={m.userId} value={m.userId}>
                      {m.name ?? m.email}
                    </option>
                  ))}
                </Select>
                <Button type="submit" variant="secondary" disabled={!assign[t.id]} pending={add.isPending && add.variables?.teamId === t.id}>
                  Asignar
                </Button>
              </form>
              {assigned === t.id && add.isSuccess ? <p className="text-step--1 text-accent-strong sm:col-span-2">Asignado.</p> : null}
            </li>
          ))}
        </ul>
        {add.isError ? <Notice tone="attention" title={errorText(add.error)} /> : null}
      </Section>
    </div>
  );
}

// ───────────────────────────── Miembros e invitaciones ─────────────────────────────

function SeatMeter() {
  const { companyId } = useCompany();
  const seats = useSeats(companyId);
  if (!seats.data) return null;
  const { used, seats: total } = seats.data;
  const pct = total ? Math.min(100, (used / total) * 100) : 0;
  return (
    <div className="grid max-w-md gap-2">
      <p className="flex items-baseline gap-2">
        <span className="font-display text-step-3">{used}</span>
        <span className="text-ink-soft">de {total ?? "—"} puestos en uso</span>
      </p>
      <div className="h-1.5 overflow-hidden rounded-full bg-paper-3" role="progressbar" aria-valuenow={used} aria-valuemin={0} aria-valuemax={total ?? used} aria-label="Puestos usados">
        <div className={`h-full ${pct >= 100 ? "bg-warm" : "bg-accent"}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

export function MembersManager() {
  const { companyId } = useCompany();
  const members = useMembers(companyId);
  const invites = useInvites(companyId);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<"MEMBER" | "ADMIN">("MEMBER");
  const invite = useCompanyMutation(companyId, () => unwrap(api.POST("/companies/{companyId}/invites", { params: { path: { companyId } }, body: { email: email.trim(), role } })));
  const revoke = useCompanyMutation(companyId, (inviteId: string) => unwrap(api.DELETE("/companies/{companyId}/invites/{inviteId}", { params: { path: { companyId, inviteId } } })));

  return (
    <div className="grid gap-14">
      <Section title="Puestos">
        <SeatMeter />
      </Section>

      <Section title="Invitar por correo" description="Le llegará un enlace válido por unos días. Al aceptarlo ocupa un puesto.">
        <form
          className="flex flex-wrap items-end gap-3"
          onSubmit={(e) => {
            e.preventDefault();
            invite.mutate(undefined, { onSuccess: () => setEmail("") });
          }}
        >
          <Input label="Correo" type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-72" />
          <Select label="Rol" value={role} onChange={(e) => setRole(e.target.value as "MEMBER" | "ADMIN")} className="w-44">
            <option value="MEMBER">Integrante</option>
            <option value="ADMIN">Administración</option>
          </Select>
          <Button type="submit" disabled={!email.includes("@")} pending={invite.isPending}>
            Enviar invitación
          </Button>
        </form>
        {invite.isSuccess ? <Notice tone="calm" role="status" title="Invitación enviada." /> : null}
        {invite.isError ? <Notice tone="attention" role="alert" title={errorText(invite.error)} /> : null}
      </Section>

      <Section title="Invitaciones">
        {invites.isPending ? <Loading /> : null}
        {invites.data && !invites.data.length ? <Empty title="Sin invitaciones">Las que envíes aparecerán aquí con su estado.</Empty> : null}
        <ul className="grid border-t border-line">
          {invites.data?.map((i) => (
            <li key={i.id} className="flex flex-wrap items-center justify-between gap-3 border-b border-line py-3">
              <div className="grid gap-0.5">
                <span className="figures text-sm">{i.email}</span>
                <span className="text-xs text-ink-faint">
                  {companyCopy.roles[i.role]} · vence {fmt(i.expiresAt)}
                </span>
              </div>
              <div className="flex items-center gap-3">
                <Badge tone={i.status === "ACCEPTED" ? "calm" : i.status === "PENDING" ? "neutral" : "attention"}>{companyCopy.inviteStatus[i.status]}</Badge>
                {i.status === "PENDING" ? (
                  <Button size="sm" variant="ghost" pending={revoke.isPending && revoke.variables === i.id} onClick={() => revoke.mutate(i.id)}>
                    Revocar
                  </Button>
                ) : null}
              </div>
            </li>
          ))}
        </ul>
        {revoke.isError ? <Notice tone="attention" title={errorText(revoke.error)} /> : null}
      </Section>

      <Section title="Miembros" description="Solo datos de la organización: nunca de bienestar.">
        {members.isPending ? <Loading /> : null}
        <ul className="grid border-t border-line">
          {members.data?.map((m) => (
            <li key={m.userId} className="flex flex-wrap items-baseline justify-between gap-3 border-b border-line py-3">
              <span>
                {m.name} <span className="figures text-xs text-ink-faint">{m.email}</span>
              </span>
              <span className="text-step--1 text-ink-soft">{companyCopy.roles[m.role]}</span>
            </li>
          ))}
        </ul>
      </Section>
    </div>
  );
}

// ───────────────────────────── Ajustes, plan y auditoría ─────────────────────────────

function SeatsForm() {
  const { companyId } = useCompany();
  const seats = useSeats(companyId);
  const plans = usePlans();
  const [value, setValue] = useState<number | null>(null);
  const update = useCompanyMutation(companyId, (n: number) => unwrap(api.PATCH("/companies/{companyId}/subscription", { params: { path: { companyId } }, body: { seats: n } })));
  if (!seats.data) return <Loading />;
  const current = value ?? seats.data.seats ?? 5;
  const price = plans.data?.find((p) => p.id === "CORPORATE")?.price.amount;

  return (
    <div className="grid gap-4">
      <div className="flex flex-wrap items-end gap-3">
        <Input label="Puestos contratados" type="number" min={Math.max(5, seats.data.used)} max={5000} value={current} onChange={(e) => setValue(Number(e.target.value))} className="w-44" hint={`En uso: ${seats.data.used}`} />
        <Button variant="secondary" disabled={current === seats.data.seats || current < 5} pending={update.isPending} onClick={() => update.mutate(current, { onSuccess: () => setValue(null) })}>
          Actualizar puestos
        </Button>
      </div>
      {price ? (
        <p className="text-ink-soft">
          {current} × ${price} = <span className="font-display text-step-1 text-ink">${current * price}</span> al mes (referencial)
        </p>
      ) : null}
      {update.isSuccess ? <Notice tone="calm" role="status" title="Puestos actualizados." /> : null}
      {update.isError ? <Notice tone="attention" role="alert" title={errorText(update.error)} /> : null}
    </div>
  );
}

export function CompanySettings() {
  const company = useCompany();
  const [k, setK] = useState(company.minAggregationSize ?? 5);
  const update = useCompanyMutation(company.companyId, (n: number) => unwrap(api.PATCH("/companies/{companyId}", { params: { path: { companyId: company.companyId } }, body: { minAggregationSize: n } })));

  return (
    <div className="grid gap-14">
      <Section
        title="Mínimo de agregación"
        description="Cuántas personas debe tener un equipo, por métrica, para mostrar su tendencia. Nunca menos de 5. Súbelo si tus equipos cambian mucho de integrantes: con grupos pequeños, sumar o quitar a alguien puede delatar su dato."
      >
        <div className="flex flex-wrap items-end gap-3">
          <Input label="Personas como mínimo" type="number" min={5} max={1000} value={k} onChange={(e) => setK(Number(e.target.value))} className="w-44" />
          <Button variant="secondary" disabled={k < 5 || k === company.minAggregationSize} pending={update.isPending} onClick={() => update.mutate(k)}>
            Guardar
          </Button>
        </div>
        {update.isSuccess ? <Notice tone="calm" role="status" title="Guardado. Se aplica en el próximo cálculo." /> : null}
        {update.isError ? <Notice tone="attention" role="alert" title={errorText(update.error)} /> : null}
      </Section>
      <Section title="Puestos">
        <SeatsForm />
      </Section>
    </div>
  );
}

export function CompanyBilling() {
  const { companyId, name } = useCompany();
  const seats = useSeats(companyId);
  return (
    <div className="grid gap-14">
      <Section title="Plan">
        <dl className="grid max-w-lg gap-3 border-y border-line py-5">
          <div className="flex justify-between gap-4">
            <dt className="text-ink-soft">Empresa</dt>
            <dd className="font-medium">{name}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-ink-soft">Plan</dt>
            <dd>{seats.data?.plan === "TEAM_SEAT" ? "Corporativo" : (seats.data?.plan ?? "—")}</dd>
          </div>
          <div className="flex justify-between gap-4">
            <dt className="text-ink-soft">Puestos</dt>
            <dd className="figures">
              {seats.data ? `${seats.data.used} / ${seats.data.seats ?? "—"}` : "—"}
            </dd>
          </div>
        </dl>
      </Section>
      <Section title="Cambiar puestos">
        <SeatsForm />
      </Section>
      <Section title="Facturación">
        <SimulatedNotice />
      </Section>
    </div>
  );
}

export function AuditLog() {
  const { companyId } = useCompany();
  const audit = useAudit(companyId);
  const members = useMembers(companyId);
  if (audit.isPending) return <Loading />;
  if (audit.isError) return <Notice tone="attention" title={errorText(audit.error)} />;
  const who = new Map((members.data ?? []).map((m) => [m.userId, m.name ?? m.email ?? m.userId]));

  return (
    <table className="w-full text-left text-sm">
      <thead className="text-ink-faint">
        <tr className="border-b border-ink">
          <th className="py-2 pr-4 font-normal">Cuándo</th>
          <th className="py-2 pr-4 font-normal">Quién</th>
          <th className="py-2 pr-4 font-normal">Qué</th>
          <th className="hidden py-2 font-normal md:table-cell">Recurso</th>
        </tr>
      </thead>
      <tbody>
        {audit.data.map((row) => (
          <tr key={row.id} className="border-b border-line align-baseline">
            <td className="figures whitespace-nowrap py-2.5 pr-4 text-xs text-ink-soft">{fmt(row.accessedAt)}</td>
            <td className="py-2.5 pr-4">{who.get(row.companyAdminUserId) ?? "Administración"}</td>
            <td className="py-2.5 pr-4">{companyCopy.audit[row.action] ?? row.action}</td>
            <td className="figures hidden py-2.5 text-xs text-ink-faint md:table-cell">{row.targetResource}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

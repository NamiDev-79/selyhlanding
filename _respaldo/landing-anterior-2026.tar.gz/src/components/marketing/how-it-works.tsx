import { Icon, type IconName } from "@/components/ui/icons";
import { how } from "@/content/landing";

import { SectionHead } from "./section-head";

const icons: IconName[] = ["pulse", "chart", "sparkle", "loop"];

export function HowItWorks() {
  return (
    <section id="como-funciona" aria-labelledby="como-funciona-title" className="relative scroll-mt-24 bg-paper-2 py-[var(--section)]">
      <div aria-hidden className="dots absolute inset-0 opacity-50 [mask-image:linear-gradient(transparent,black_30%,black_70%,transparent)]" />
      <div className="wrap relative">
        <SectionHead id="como-funciona-title" eyebrow={how.eyebrow} title={how.title} center />
        <ol className="relative mt-16 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          <span aria-hidden className="absolute left-[12%] right-[12%] top-12 hidden h-px bg-gradient-to-r from-accent/0 via-accent/50 to-accent/0 xl:block" />
          {how.steps.map((s, i) => (
            <li key={s.n} className="reveal">
              <div className="card group relative grid h-full content-start gap-4 p-6 transition-[transform,box-shadow] duration-300 hover:-translate-y-1 hover:shadow-float">
              <div className="flex items-center justify-between">
                <span className="grid size-12 place-items-center rounded-2xl bg-accent-wash text-accent-strong transition-colors group-hover:bg-accent group-hover:text-on-accent">
                  <Icon name={icons[i]!} className="size-6" />
                </span>
                <span className="figures text-sm font-medium text-ink-faint">{s.n}</span>
              </div>
              <h3 className="text-step-2">{s.title}</h3>
              <p className="text-[0.97rem] text-ink-soft">{s.body}</p>
              </div>
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}

import { ImageResponse } from "next/og";

import { hero } from "@/content/landing";
import { sampleTrend } from "@/content/sample-data";

export const alt = "Selyh: cuida tu salud mental sin salir de tu flujo de trabajo";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

/** Imagen para redes: titular + la línea de tendencia de ejemplo, con la paleta de la marca. */
export default function OpengraphImage() {
  const w = 460;
  const h = 200;
  const pts = sampleTrend.map((z, i) => `${(i / (sampleTrend.length - 1)) * w},${h / 2 - z * 60}`).join(" ");
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", background: "linear-gradient(135deg, #f6f5ff 0%, #eefbf6 60%, #fff7e8 100%)", color: "#14132b", padding: 72, justifyContent: "space-between", alignItems: "flex-end" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 28, maxWidth: 600 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10, fontSize: 44, fontWeight: 700, letterSpacing: -2 }}>
            selyh
            <div style={{ width: 16, height: 16, borderRadius: 999, background: "linear-gradient(135deg, #5b5ff0, #7ee0c0)" }} />
          </div>
          <div style={{ display: "flex", flexWrap: "wrap", fontSize: 62, fontWeight: 700, lineHeight: 1.05, letterSpacing: -2 }}>
            {hero.title.before} <span style={{ color: "#5b5ff0", marginLeft: 14 }}>{hero.title.accent}</span>
          </div>
        </div>
        <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`}>
          <rect x={0} y={h / 2 - 30} width={w} height={60} fill="#dcf7ec" rx={12} />
          <polyline points={pts} fill="none" stroke="#5b5ff0" strokeWidth={5} strokeLinejoin="round" strokeLinecap="round" />
        </svg>
      </div>
    ),
    size,
  );
}

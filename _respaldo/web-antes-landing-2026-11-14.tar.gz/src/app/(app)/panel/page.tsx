"use client";

import Link from "next/link";

import { LoadSummary } from "@/features/analytics/load-summary";
import { useMe } from "@/features/auth/hooks";
import { QuickCheckin } from "@/features/checkins/quick-checkin";
import { TodayPrompt } from "@/features/checkins/today";
import { OpenCrisisFlags } from "@/features/crisis/crisis-resources";

function greeting(h: number) {
  return h < 12 ? "Buenos días" : h < 19 ? "Buenas tardes" : "Buenas noches";
}

export default function PanelHome() {
  const me = useMe();
  const now = new Date();
  const first = me.data?.name.split(" ")[0];
  return (
    <div className="grid gap-14">
      <header className="grid gap-1">
        <p className="eyebrow">{now.toLocaleDateString("es-PE", { weekday: "long", day: "numeric", month: "long" })}</p>
        <h1 className="text-step-4">
          {greeting(now.getHours())}
          {first ? `, ${first}` : ""}
        </h1>
      </header>

      <OpenCrisisFlags />

      <div className="grid gap-14 lg:grid-cols-[1fr_1.25fr] lg:gap-16">
        <div className="grid content-start gap-12">
          <QuickCheckin />
          <TodayPrompt />
        </div>
        <div className="grid content-start gap-6 lg:border-l lg:border-line lg:pl-16">
          <LoadSummary />
          <p className="text-step--1">
            ¿Necesitas una pausa?{" "}
            <Link href="/panel/intervenciones" className="link">
              Pide un ejercicio breve
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

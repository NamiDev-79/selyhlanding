"use client";

import { useState } from "react";

import { Empty, Loading, Notice } from "@/components/ui/feedback";
import { checkinCopy } from "@/content/panel";
import { errorText } from "@/lib/api/client";
import { useScaleCatalog, useScaleHistory } from "@/features/scales/hooks";

import { useDailyCheckins } from "./hooks";

const RANGES = [30, 90, 180] as const;

/** Promedio diario de check-ins como columnas finas (1 abajo, 5 arriba); los días sin dato quedan vacíos. */
export function CheckinHistory() {
  const [days, setDays] = useState<(typeof RANGES)[number]>(30);
  const q = useDailyCheckins(days);

  return (
    <section className="grid gap-5">
      <div className="flex flex-wrap items-baseline justify-between gap-4">
        <h2 className="text-step-2">Check-ins por día</h2>
        <div role="group" aria-label="Rango" className="flex gap-1">
          {RANGES.map((r) => (
            <button key={r} aria-pressed={days === r} onClick={() => setDays(r)} className="rounded-ui px-2.5 py-1 font-mono text-xs text-ink-soft aria-pressed:bg-ink aria-pressed:text-paper">
              {r} d
            </button>
          ))}
        </div>
      </div>
      {q.isPending ? <Loading /> : null}
      {q.isError ? <Notice tone="attention" title={errorText(q.error)} /> : null}
      {q.data && !q.data.length ? <Empty title="Sin check-ins en este rango">Haz tu primer check-in desde Inicio o desde la extensión del editor.</Empty> : null}
      {q.data?.length ? <DailyBars rows={q.data} days={days} /> : null}
    </section>
  );
}

function DailyBars({ rows, days }: { rows: { date: string; avg: number; count: number }[]; days: number }) {
  const byDate = new Map(rows.map((r) => [r.date, r]));
  const today = new Date();
  const cells = Array.from({ length: days }, (_, i) => {
    const d = new Date(today.getTime() - (days - 1 - i) * 86_400_000);
    const key = d.toLocaleDateString("en-CA"); // YYYY-MM-DD en la zona local
    return { key, row: byDate.get(key) };
  });
  const label = (v: number) => checkinCopy.scale[Math.round(v) - 1]?.label ?? "";
  const avg = rows.reduce((a, r) => a + r.avg, 0) / rows.length;

  return (
    <figure className="grid gap-3">
      <div className="flex h-40 items-end gap-px border-b border-line-strong" role="img" aria-label={`Promedio diario de check-ins en ${days} días. Promedio del periodo: ${avg.toFixed(1)} (${label(avg)}).`}>
        {cells.map(({ key, row }) => (
          <div key={key} className="flex h-full flex-1 items-end" title={row ? `${key}: ${row.avg} (${row.count})` : `${key}: sin dato`}>
            {row ? <div className={`w-full rounded-t-[1px] ${row.avg >= 4 ? "bg-warm" : "bg-accent"}`} style={{ height: `${(row.avg / 5) * 100}%` }} /> : null}
          </div>
        ))}
      </div>
      <figcaption className="flex flex-wrap justify-between gap-2 font-mono text-[11px] text-ink-faint">
        <span>hace {days} días</span>
        <span>
          promedio {avg.toFixed(1)} · {label(avg).toLowerCase()}
        </span>
        <span>hoy</span>
      </figcaption>
    </figure>
  );
}

/** Evolución de cada escala: puntaje sobre el máximo, del más antiguo al más reciente. */
export function ScaleEvolution() {
  const catalog = useScaleCatalog();
  const history = useScaleHistory();
  if (history.isPending || catalog.isPending) return <Loading />;
  if (history.isError) return <Notice tone="attention" title={errorText(history.error)} />;
  if (!history.data.length) return <Empty title="Aún no hay escalas respondidas">Responde una escala en la sección Escalas. Verás aquí cómo cambia con las semanas.</Empty>;

  return (
    <dl className="grid border-t border-line">
      {(catalog.data ?? []).map((s) => {
        const rows = history.data.filter((h) => h.instrument === s.code).reverse();
        if (!rows.length) return null;
        return (
          <div key={s.code} className="grid gap-3 border-b border-line py-5 sm:grid-cols-[12rem_1fr] sm:gap-8">
            <dt className="grid content-start gap-1">
              <span className="font-medium">{s.name}</span>
              <span className="figures text-xs text-ink-faint">máx. {s.maxScore}</span>
            </dt>
            <dd className="flex flex-wrap items-end gap-3">
              {rows.map((r) => (
                <span key={r.id} className="grid justify-items-center gap-1">
                  <span className="flex h-16 w-6 items-end bg-paper-2">
                    <span className="w-full bg-ink-soft" style={{ height: `${(r.totalScore / s.maxScore) * 100}%` }} />
                  </span>
                  <span className="figures text-[11px]">{r.totalScore}</span>
                  <span className="figures text-[10px] text-ink-faint">{new Date(r.completedAt).toLocaleDateString("es-PE", { day: "2-digit", month: "2-digit" })}</span>
                </span>
              ))}
            </dd>
          </div>
        );
      })}
    </dl>
  );
}

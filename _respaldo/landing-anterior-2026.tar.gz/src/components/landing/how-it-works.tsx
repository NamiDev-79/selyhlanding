"use client";

import { motion } from "motion/react";
import { useState } from "react";

import { PauseBars } from "@/components/brand/logo";
import { Button } from "@/components/shadcn/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/shadcn/tabs";
import { how } from "@/content/landing";
import { cn } from "@/lib/utils";

import { EASE, Eyebrow, Reveal, SectionTitle, Wrap } from "./primitives";

/* ---------- Visuales de cada paso ---------- */

function Measure() {
  return (
    <div className="mx-auto w-full max-w-sm rounded-2xl border border-border bg-background p-5 shadow-[0_18px_40px_-28px_rgb(15_21_35/0.35)]">
      <p className="flex items-center gap-2 font-display text-lg font-semibold">
        <PauseBars className="h-4 w-auto" />
        ¿Cómo vas?
      </p>
      <div className="mt-4 grid grid-cols-5 gap-1.5" aria-hidden>
        {[1, 2, 3, 4, 5].map((n) => (
          <span key={n} className={cn("grid h-11 place-items-center rounded-[10px] border text-base font-semibold tabular", n === 2 ? "border-primary bg-primary text-primary-foreground" : "border-border text-muted-foreground")}>
            {n}
          </span>
        ))}
      </div>
      <div className="mt-2 flex justify-between text-[0.8125rem] text-muted-foreground">
        <span>tranquilo</span>
        <span>sobrecargado</span>
      </div>
      <p className="mt-4 border-t border-border pt-3 text-[0.875rem] text-muted-foreground">Un toque, una o dos veces al día. En el IDE o en el escritorio.</p>
    </div>
  );
}

/* Carga diaria de ejemplo (28 días): 14 de calibración, luego tendencia que sale del rango habitual. */
const DAYS = [2.4, 2.9, 2.2, 3.1, 2.6, 2.8, 2.1, 2.7, 3.0, 2.5, 2.3, 2.9, 2.6, 2.8, 2.7, 2.5, 3.0, 2.8, 3.1, 3.3, 3.2, 3.5, 3.4, 3.7, 3.6, 3.9, 3.8, 4.1];
const W = 420;
const H = 220;
const px = (i: number) => 16 + (i * (W - 32)) / (DAYS.length - 1);
const py = (v: number) => H - 24 - ((v - 1) / 4) * (H - 48);
const path = DAYS.map((v, i) => `${i ? "L" : "M"}${px(i).toFixed(1)} ${py(v).toFixed(1)}`).join(" ");

function Interpret() {
  return (
    <figure className="w-full max-w-md">
      <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Gráfico de ejemplo: tras 14 días de calibración, la carga sale por encima del rango habitual.">
        <rect x={px(13)} y={py(3.15)} width={px(27) - px(13)} height={py(2.35) - py(3.15)} rx="6" fill="var(--brand-tint)" />
        <line x1={px(13)} x2={px(13)} y1="12" y2={H - 20} stroke="var(--border)" strokeDasharray="3 4" />
        <text x={px(6.5)} y="18" textAnchor="middle" fontSize="11" fill="var(--muted-foreground)">
          calibrando · 14 días
        </text>
        <text x={px(20)} y={py(2.35) + 16} textAnchor="middle" fontSize="11" fill="var(--brand-strong)">
          tu rango habitual
        </text>
        <motion.path
          d={path}
          fill="none"
          stroke="var(--brand)"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeLinejoin="round"
          initial={{ pathLength: 0 }}
          animate={{ pathLength: 1 }}
          transition={{ duration: 1.4, ease: EASE }}
        />
        <motion.circle cx={px(27)} cy={py(DAYS[27])} r="5" fill="var(--brand)" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ delay: 1.3, duration: 0.4, ease: EASE }} />
      </svg>
      <figcaption className="mt-3 text-[0.875rem] text-muted-foreground">
        <span className="font-medium text-foreground">Tu carga viene subiendo</span> respecto a tu línea base. Datos de ejemplo.
      </figcaption>
    </figure>
  );
}

function Intervene() {
  return (
    <div className="mx-auto grid w-full max-w-sm justify-items-center gap-5 rounded-2xl border border-border bg-background p-6 text-center shadow-[0_18px_40px_-28px_rgb(15_21_35/0.35)]">
      <div className="flex h-24 items-end gap-3" aria-hidden>
        <span className="h-24 w-5 rounded-full bg-primary" />
        <motion.span
          className="h-[3.7rem] w-5 origin-bottom rounded-full bg-brand-soft"
          animate={{ scaleY: [1, 0.62, 1] }}
          transition={{ duration: 10, times: [0, 0.4, 1], ease: "easeInOut", repeat: Infinity }}
        />
      </div>
      <div>
        <p className="font-display text-lg font-semibold">Respiración guiada · 2 min</p>
        <p className="mt-1 text-[0.875rem] text-muted-foreground">Inhala 4 segundos, suelta en 6. Sin salir del editor.</p>
      </div>
      <span className="inline-flex h-10 items-center rounded-full bg-primary px-5 text-[0.9375rem] font-medium text-primary-foreground">Empezar pausa</span>
    </div>
  );
}

function Evaluate() {
  const [answer, setAnswer] = useState<string | null>(null);
  return (
    <div className="mx-auto w-full max-w-sm rounded-2xl border border-border bg-background p-5 shadow-[0_18px_40px_-28px_rgb(15_21_35/0.35)]">
      <p className="font-display text-lg font-semibold" id="evaluar-pregunta">
        ¿Te sirvió la pausa?
      </p>
      <div role="group" aria-labelledby="evaluar-pregunta" className="mt-4 flex flex-wrap gap-2">
        {["Sí", "Un poco", "No"].map((a) => (
          <Button key={a} size="sm" variant={answer === a ? "default" : "outline"} aria-pressed={answer === a} onClick={() => setAnswer(a)}>
            {a}
          </Button>
        ))}
      </div>
      <p aria-live="polite" className="mt-4 min-h-[2.75rem] border-t border-border pt-3 text-[0.875rem] text-muted-foreground">
        {answer ? "Gracias. Con tu respuesta ajustamos lo que te sugerimos la próxima vez." : "Tu respuesta ajusta las próximas sugerencias."}
      </p>
    </div>
  );
}

const visuals = [Measure, Interpret, Intervene, Evaluate];

/** Cómo funciona: cuatro pasos (medir, interpretar, intervenir, evaluar) con su visual a la derecha. */
export function HowItWorks() {
  const [step, setStep] = useState("0");

  return (
    <section id="como-funciona" aria-labelledby="como-title" className="scroll-mt-24 bg-surface-raised py-[clamp(4.5rem,3rem+5vw,7rem)]">
      <Wrap>
        <Reveal className="grid gap-[26px]">
          <Eyebrow n="02">{how.eyebrow}</Eyebrow>
          <SectionTitle id="como-title">{how.title}</SectionTitle>
        </Reveal>

        <Tabs value={step} onValueChange={setStep} orientation="vertical" className="mt-12 grid gap-10 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.15fr)] lg:gap-[68px]">
          <TabsList aria-label="Pasos" className="flex h-auto w-full flex-col items-stretch gap-0 rounded-none bg-transparent p-0">
            {how.steps.map((s, i) => (
              <TabsTrigger
                key={s.n}
                value={String(i)}
                className="group grid w-full grid-cols-[2.5rem_1fr] items-start justify-items-start gap-x-3 rounded-none border-t border-border px-0 py-5 text-left text-foreground last:border-b hover:text-foreground data-[state=active]:bg-transparent data-[state=active]:shadow-none"
              >
                <span className="pt-1 text-[0.8125rem] font-medium text-muted-foreground tabular group-data-[state=active]:text-brand-strong">{s.n}</span>
                <span className="grid gap-2">
                  <span className="font-display text-[1.375rem] font-bold leading-tight tracking-[-0.015em] text-muted-foreground transition-colors group-hover:text-foreground group-data-[state=active]:text-foreground">
                    {s.title}
                  </span>
                  <span className="hidden max-w-[46ch] whitespace-normal text-[0.9375rem] font-normal leading-relaxed text-muted-foreground group-data-[state=active]:block">{s.body}</span>
                </span>
              </TabsTrigger>
            ))}
          </TabsList>

          {visuals.map((Visual, i) => (
            <TabsContent key={i} value={String(i)} className="m-0">
              <motion.div
                initial={{ opacity: 0, y: 12 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.45, ease: EASE }}
                className="grid min-h-[22rem] place-items-center rounded-[28px] bg-background p-6 sm:p-10"
              >
                <Visual />
              </motion.div>
            </TabsContent>
          ))}
        </Tabs>
      </Wrap>
    </section>
  );
}

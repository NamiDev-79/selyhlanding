import { SiteFooter } from "@/components/layout/site-footer";
import { SiteHeader } from "@/components/layout/site-header";

/** La web pública es siempre clara, aunque el sistema esté en modo oscuro (el panel sí lo respeta). */
export default function MarketingLayout({ children }: { children: React.ReactNode }) {
  return (
    <div data-theme="light" className="min-h-dvh bg-paper text-ink">
      <SiteHeader />
      <main id="contenido">{children}</main>
      <SiteFooter />
    </div>
  );
}

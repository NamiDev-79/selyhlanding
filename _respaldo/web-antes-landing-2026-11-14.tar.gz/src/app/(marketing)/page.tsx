import { Facts } from "@/components/marketing/facts";
import { FaqList } from "@/components/marketing/faq";
import { FinalCta } from "@/components/marketing/final-cta";
import { Hero } from "@/components/marketing/hero";
import { HowItWorks } from "@/components/marketing/how-it-works";
import { Plans } from "@/components/marketing/plans";
import { Privacy } from "@/components/marketing/privacy";
import { Problem } from "@/components/marketing/problem";
import { Science } from "@/components/marketing/science";
import { SectionHead } from "@/components/marketing/section-head";
import { Teams } from "@/components/marketing/teams";
import { Where } from "@/components/marketing/where";
import { faq } from "@/content/faq";
import { formsSection } from "@/content/landing";
import { LeadForms } from "@/features/leads/lead-forms";
import { LandingJsonLd } from "@/lib/seo/json-ld";

export default function LandingPage() {
  return (
    <>
      <LandingJsonLd />
      <Hero />
      <Facts />
      <Problem />
      <HowItWorks />
      <Where />
      <Privacy />
      <Teams />
      <Science />
      <Plans />

      <section id="preguntas" aria-labelledby="preguntas-title" className="wrap grid scroll-mt-24 gap-12 py-[var(--section)] pt-0 lg:grid-cols-[1fr_1.6fr] lg:gap-20">
        <SectionHead id="preguntas-title" eyebrow={faq.eyebrow} title={faq.title} className="content-start lg:sticky lg:top-28 lg:self-start" />
        <div className="reveal">
          <FaqList />
        </div>
      </section>

      <section id="contacto" aria-labelledby="contacto-title" className="wrap scroll-mt-24">
        <div className="grid gap-12 rounded-[2rem] border border-line bg-paper-2 p-6 sm:p-10 lg:grid-cols-[1fr_1.5fr] lg:gap-16 lg:p-14">
          <SectionHead id="contacto-title" eyebrow={formsSection.eyebrow} title={formsSection.title} className="content-start" />
          <div className="reveal card p-6 sm:p-8">
            <LeadForms />
          </div>
        </div>
      </section>

      <FinalCta />
    </>
  );
}

"use client";

import Link from "next/link";

import { Skeleton } from "@/components/ui/feedback";
import { todayCopy } from "@/content/panel";

import { useNextPrompt } from "./hooks";

/** Qué toca hoy según GET /prompts/next: check-in pendiente y tanda de escala sugerida. */
export function TodayPrompt() {
  const q = useNextPrompt();
  const c = todayCopy;
  if (q.isPending) return <Skeleton className="h-24" />;
  if (q.isError) return null;
  const p = q.data;

  const items: React.ReactNode[] = [];
  if (p.quiet) items.push(c.quiet);
  else {
    items.push(p.checkIn.due ? c.checkinDue : c.checkinDone(p.checkIn.doneToday, p.checkIn.target));
    if (p.scale) {
      items.push(
        <Link href={`/panel/escalas?code=${p.scale.code}`} className="link">
          {p.scale.reason === "IN_PROGRESS" ? c.scaleInProgress(p.scale.name, p.scale.answered, p.scale.total) : c.scaleDue(p.scale.name)}
        </Link>,
      );
    }
  }

  return (
    <section aria-labelledby="hoy" className="grid gap-3">
      <h2 id="hoy" className="eyebrow">
        {c.title}
      </h2>
      <ul className="grid gap-2">
        {items.map((it, i) => (
          <li key={i} className="flex gap-3">
            <span aria-hidden className="mt-[0.72em] h-px w-4 shrink-0 bg-accent" />
            <span>{it}</span>
          </li>
        ))}
      </ul>
      {p.bestHours.length ? (
        <p className="text-step--1 text-ink-faint">
          {c.bestHours} <span className="figures">{p.bestHours.map((h) => `${String(h).padStart(2, "0")}:00`).join(", ")}</span>
        </p>
      ) : null}
    </section>
  );
}

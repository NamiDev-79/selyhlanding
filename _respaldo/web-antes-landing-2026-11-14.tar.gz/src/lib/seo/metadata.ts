import type { Metadata } from "next";

import { site } from "@/content/site";

export const siteMetadata: Metadata = {
  metadataBase: new URL(site.url),
  title: { default: `${site.name} · ${site.tagline}`, template: `%s · ${site.name}` },
  description: site.description,
  applicationName: site.name,
  icons: {
    icon: [{ url: "/favicon.svg", type: "image/svg+xml" }],
  },
  openGraph: { type: "website", siteName: site.name, locale: site.locale, url: "/" },
  twitter: { card: "summary_large_image" },
  alternates: { canonical: "/" },
};

/** Metadatos de una página pública: título, descripción y URL canónica. */
export function pageMetadata(path: string, title: string, description: string): Metadata {
  return {
    title,
    description,
    alternates: { canonical: path },
    openGraph: { title, description, url: path },
  };
}

/** Paneles y flujos de cuenta: nunca indexar. */
export const privateMetadata: Metadata = { robots: { index: false, follow: false } };

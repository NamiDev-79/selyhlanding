"use client";

import { zodResolver } from "@hookform/resolvers/zod";
import { useState } from "react";
import { useForm } from "react-hook-form";
import { z } from "zod";

import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/feedback";
import { Input, Textarea } from "@/components/ui/field";
import { formsSection } from "@/content/landing";
import { api, errorText, unwrap } from "@/lib/api/client";

type Kind = "WAITLIST" | "CONTACT" | "DEMO";
const KINDS: Kind[] = ["WAITLIST", "CONTACT", "DEMO"];

const schema = z.object({
  email: z.email("Escribe un correo válido").max(254),
  name: z.string().trim().max(100).optional(),
  company: z.string().trim().max(120).optional(),
  message: z.string().trim().max(2000).optional(),
  website: z.string().max(200).optional(), // campo trampa para bots
});
type Values = z.infer<typeof schema>;

/** Formularios de la landing: lista de espera, contacto y demo corporativa (POST /public/leads). */
export function LeadForms() {
  const [kind, setKind] = useState<Kind>("WAITLIST");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const form = useForm<Values>({ resolver: zodResolver(schema) });
  const tab = formsSection.tabs[kind];

  const submit = form.handleSubmit(async (v) => {
    setError(null);
    try {
      await unwrap(
        api.POST("/public/leads", {
          body: { kind, email: v.email, name: v.name || undefined, company: v.company || undefined, message: v.message || undefined, website: v.website || undefined },
        }),
      );
      setSent(true);
      form.reset();
    } catch (e) {
      setError(errorText(e));
    }
  });

  return (
    <div className="grid gap-8">
      <div role="tablist" aria-label="Tipo de formulario" className="flex flex-wrap gap-1 rounded-2xl bg-paper-2 p-1 sm:w-fit sm:rounded-full">
        {KINDS.map((k) => (
          <button
            key={k}
            role="tab"
            type="button"
            aria-selected={kind === k}
            aria-controls="panel-formulario"
            onClick={() => {
              setKind(k);
              setSent(false);
              setError(null);
            }}
            className={`rounded-full px-4 py-2 text-[0.93rem] transition-all ${kind === k ? "bg-paper font-semibold text-ink shadow-card" : "text-ink-soft hover:text-ink"}`}
          >
            {formsSection.tabs[k].label}
          </button>
        ))}
      </div>

      <form id="panel-formulario" role="tabpanel" onSubmit={submit} noValidate className="grid gap-5">
        <p className="text-ink-soft">{tab.intro}</p>
        <div className="grid gap-5 sm:grid-cols-2">
          <Input label="Correo" type="email" autoComplete="email" error={form.formState.errors.email?.message} {...form.register("email")} />
          {kind !== "WAITLIST" ? <Input label="Nombre" autoComplete="name" {...form.register("name")} /> : null}
          {kind === "DEMO" ? <Input label="Empresa" autoComplete="organization" {...form.register("company")} /> : null}
        </div>
        {kind !== "WAITLIST" ? (
          <Textarea label={kind === "DEMO" ? "Cuéntanos sobre tu equipo (opcional)" : "Mensaje"} hint={kind === "DEMO" ? "Tamaño, si hacen guardias, qué les preocupa." : undefined} {...form.register("message")} />
        ) : null}
        <div aria-hidden className="absolute -left-[9999px]">
          <label>
            Sitio web
            <input tabIndex={-1} autoComplete="off" {...form.register("website")} />
          </label>
        </div>
        {sent ? (
          <Notice tone="calm" role="status" title={formsSection.success} />
        ) : error ? (
          <Notice tone="attention" role="alert" title={error} />
        ) : null}
        <div>
          <Button type="submit" pending={form.formState.isSubmitting}>
            {tab.submit}
          </Button>
        </div>
      </form>
    </div>
  );
}

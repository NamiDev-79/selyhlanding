import { Icon, type IconName } from "@/components/ui/icons";
import { privacy } from "@/content/landing";

const icons: IconName[] = ["toggle", "hash", "download", "shield"];

/** Banda oscura: la promesa más importante del producto, con el mayor contraste de la página. */
export function Privacy() {
  return (
    <section id="privacidad" aria-labelledby="privacidad-title" className="scroll-mt-24 px-[clamp(0.5rem,0.2rem+1vw,1.25rem)]">
      <div className="relative isolate overflow-hidden rounded-[2rem] bg-night text-white">
        <div aria-hidden className="absolute -left-32 -top-40 -z-10 size-[30rem] rounded-full bg-[oklch(50%_0.2_277/0.45)] blur-3xl" />
        <div aria-hidden className="absolute -bottom-40 right-0 -z-10 size-[26rem] rounded-full bg-[oklch(60%_0.12_168/0.3)] blur-3xl" />
        <div className="wrap grid gap-14 py-[var(--section)] lg:grid-cols-[0.9fr_1.4fr] lg:gap-20">
          <div className="reveal grid content-start gap-6">
            <p className="inline-flex w-fit items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3 py-1 text-sm text-white/80">
              <Icon name="shield" className="size-4 text-mint" />
              {privacy.eyebrow}
            </p>
            <h2 id="privacidad-title" className="max-w-[12ch] text-step-5">
              {privacy.title}
            </h2>
            <div className="mt-4 grid gap-3">
              <p className="eyebrow text-white/60!">{privacy.never.label}</p>
              <ul className="flex flex-wrap gap-2">
                {privacy.never.items.map((item) => (
                  <li key={item} className="flex items-center gap-1.5 rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-sm text-white/85">
                    <Icon name="eyeOff" className="size-3.5 text-warm" />
                    <span className="line-through decoration-warm/80">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          <dl className="grid gap-4 sm:grid-cols-2">
            {privacy.promises.map((p, i) => (
              <div key={p.title} className={`reveal ${i % 2 === 1 ? "sm:translate-y-10" : ""}`}>
                <div className="grid h-full content-start gap-3 rounded-2xl border border-white/10 bg-white/[0.04] p-6 backdrop-blur transition-colors hover:border-white/25 hover:bg-white/[0.07]">
                  <span className="grid size-10 place-items-center rounded-xl bg-white/10 text-mint">
                    <Icon name={icons[i]!} />
                  </span>
                  <dt className="font-display text-step-1 font-semibold">{p.title}</dt>
                  <dd className="text-[0.95rem] text-white/70">{p.body}</dd>
                </div>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </section>
  );
}

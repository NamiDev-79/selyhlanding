"use client";

import * as RadixSwitch from "@radix-ui/react-switch";
import { type ReactNode, useId } from "react";

type Props = {
  label: ReactNode;
  description?: ReactNode;
  checked: boolean;
  onCheckedChange: (value: boolean) => void;
  disabled?: boolean;
};

export function Switch({ label, description, checked, onCheckedChange, disabled }: Props) {
  const id = useId();
  return (
    <div className="flex items-start justify-between gap-6">
      <div className="grid gap-0.5">
        <label htmlFor={id} className="font-medium text-ink">
          {label}
        </label>
        {description ? <p className="text-step--1 text-ink-soft">{description}</p> : null}
      </div>
      <RadixSwitch.Root
        id={id}
        checked={checked}
        onCheckedChange={onCheckedChange}
        disabled={disabled}
        className="relative mt-1 h-6 w-11 shrink-0 rounded-full border border-line-strong bg-paper-3 transition-colors data-[state=checked]:border-accent-strong data-[state=checked]:bg-accent-strong disabled:opacity-50"
      >
        <RadixSwitch.Thumb className="block size-4.5 translate-x-0.5 rounded-full bg-paper shadow-sm transition-transform duration-200 data-[state=checked]:translate-x-[1.3rem]" />
      </RadixSwitch.Root>
    </div>
  );
}

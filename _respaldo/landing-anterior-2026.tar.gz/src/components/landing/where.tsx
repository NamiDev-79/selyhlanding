"use client";

import { motion } from "motion/react";

import { Isotipo, PauseBars } from "@/components/brand/logo";
import { where } from "@/content/landing";

import { EASE, Eyebrow, Reveal, SectionTitle, Wrap } from "./primitives";

/** Dónde vive Selyh: en el editor, en el escritorio, en el móvil y en la web. */
export function Where() {
  return (
    <section aria-labelledby="donde-title" className="py-[clamp(4.5rem,3rem+5vw,7rem)]">
      <Wrap>
        <div className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:items-end lg:gap-[68px]">
          <Reveal className="grid gap-[26px]">
            <Eyebrow n="03">{where.eyebrow}</Eyebrow>
            <SectionTitle id="donde-title">{where.title}</SectionTitle>
          </Reveal>

          {/* Las dos caras más frecuentes: la barra de estado del editor y el aviso del escritorio. */}
          <Reveal delay={0.1} className="grid gap-4" aria-hidden>
            <div className="flex items-center justify-between gap-4 overflow-hidden rounded-xl bg-[#0F1523] px-4 py-2.5 text-[12.5px] text-white/60">
              <span className="truncate">Ln 42, Col 7 · UTF-8 · TypeScript</span>
              <span className="flex shrink-0 items-center gap-2 rounded-md bg-white/[0.07] px-2.5 py-1 text-white">
                <PauseBars className="h-3 w-auto" />
                {where.statusBar.question}
                <span className="hidden text-white/55 sm:inline">{where.statusBar.hint}</span>
              </span>
            </div>
            <div className="ml-auto flex w-full max-w-[22rem] items-start gap-3 rounded-2xl border border-border bg-background p-4 shadow-[0_24px_48px_-28px_rgb(15_21_35/0.35)]">
              <Isotipo className="size-9 shrink-0 rounded-[9px]" />
              <div className="min-w-0">
                <p className="flex items-baseline justify-between gap-3 text-[0.9375rem] font-semibold">
                  {where.notification.title}
                  <span className="text-[0.75rem] font-normal text-muted-foreground">ahora</span>
                </p>
                <p className="text-[0.9375rem] leading-snug text-muted-foreground">{where.notification.body}</p>
              </div>
            </div>
          </Reveal>
        </div>

        <ul className="mt-14 grid gap-x-8 gap-y-10 border-t border-border pt-10 sm:grid-cols-2 lg:grid-cols-4">
          {where.places.map((p, i) => (
              <motion.li
                key={p.name}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.6, ease: EASE, delay: i * 0.06 }}
                className="grid content-start gap-3"
              >
                  <span className="text-[0.8125rem] font-medium text-muted-foreground tabular">{String(i + 1).padStart(2, "0")}</span>
                  <h3 className="font-display text-xl font-bold tracking-[-0.01em]">{p.name}</h3>
                  <p className="text-[0.9375rem] leading-relaxed text-muted-foreground">{p.body}</p>
              </motion.li>
          ))}
        </ul>
      </Wrap>
    </section>
  );
}

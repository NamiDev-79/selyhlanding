/**
 * Texto de la landing, sección por sección y en el orden en que aparece.
 * Edita aquí sin tocar componentes. Tono: sereno, cercano y directo; sin alarmas ni promesas médicas.
 */

export const hero = {
  badge: "Lista de espera abierta · Extensión de VS Code",
  title: { before: "Cuida tu salud mental", accent: "sin salir de tu flujo de trabajo" },
  lead: "Un check-in de un toque desde tu editor. Selyh aprende cuál es tu ritmo normal y te avisa con calma cuando tu carga empieza a subir, antes de que lo note tu cuerpo.",
  primary: { label: "Crear cuenta gratis", href: "/registro" },
  secondary: { label: "Ver cómo funciona", href: "#como-funciona" },
  trust: ["Gratis en lo esencial", "Nunca lee tu código", "Tus datos, exportables"],
  chart: {
    title: "Tu carga frente a tu línea base",
    note: "Datos de ejemplo",
    callout: "Tu carga viene subiendo respecto a tu línea base",
    bandLabel: "tu rango habitual",
  },
  /** Demo interactiva de la portada: la respuesta que daría Selyh a cada valor del check-in. */
  demo: {
    file: "pagos/servicio.ts — api",
    question: "¿Cómo vas?",
    hint: "Pruébalo: elige un número",
    scale: ["tranquilo", "bien", "normal", "cargado", "sobrecargado"],
    replies: {
      1: { title: "Anotado. Vas por debajo de tu rango habitual.", body: "Buen día para la tarea difícil que vienes postergando." },
      2: { title: "Anotado. Estás dentro de tu rango habitual.", body: "Sigue así. Te volvemos a preguntar en tu próxima pausa natural." },
      3: { title: "Anotado. Un día normal para ti.", body: "Nada que hacer. Selyh solo aprende tu ritmo." },
      4: { title: "Tu carga viene subiendo frente a tu línea base.", body: "¿Una pausa de 2 minutos? Respiración guiada, sin salir del editor." },
      5: { title: "Llevas varios días por encima de lo habitual.", body: "Te sugerimos parar 5 minutos ahora y revisar qué se puede mover de la semana." },
    } as Record<number, { title: string; body: string }>,
    action: "Empezar pausa de 2 min",
  },
};

/** Cifras del producto (no estadísticas de uso): lo que Selyh promete y cumple por diseño. */
export const facts = [
  { value: "1", unit: "toque", label: "por check-in, desde tu editor" },
  { value: "14", unit: "días", label: "para conocer tu línea base" },
  { value: "≤2", unit: "al día", label: "sugerencias como máximo" },
  { value: "0", unit: "líneas", label: "de tu código leídas, jamás" },
];

/** Momentos en los que aparece el check-in: la cinta que corre bajo la portada. */
export const moments = ["después de un commit", "al cerrar un PR", "antes de la daily", "tras una guardia", "al terminar un deploy", "cuando vuelves de almorzar", "al cerrar el día"];

export const problem = {
  eyebrow: "El problema",
  title: "El cansancio no avisa: se acumula entre un commit y otro",
  body: [
    "Horas seguidas frente al PC, sin pausas reales. Deadlines, guardias, reuniones que se encadenan. Pierdes la noción del tiempo y el cuerpo queda en segundo plano.",
    "El burnout suele notarse tarde: cuando ya cuesta concentrarse o alguien deja el equipo. Y las apps de bienestar no ayudan mucho si interrumpen a cada rato o viven en un celular que apagas para poder trabajar.",
  ],
  day: {
    label: "Un martes cualquiera",
    events: [
      { time: "08:40", text: "Abres el editor" },
      { time: "10:00", text: "Daily que se alarga" },
      { time: "12:15", text: "Bug en producción" },
      { time: "15:30", text: "Revisión de código" },
      { time: "19:10", text: "Deploy fuera de horario" },
      { time: "22:05", text: "Guardia" },
    ],
    pause: "Pausas reales: 0",
  },
};

export const how = {
  eyebrow: "Cómo funciona",
  title: "Cuatro pasos que se repiten en silencio",
  steps: [
    { n: "01", title: "Medir", body: "Un check-in de un toque (del 1 al 5) dentro del IDE o del escritorio, una o dos veces al día. Si quieres, sumas señales como horas activas o reuniones: siempre tú decides." },
    { n: "02", title: "Interpretar", body: "Te comparamos contigo, no con otras personas. Tras unas dos semanas Selyh conoce tu línea base y te muestra tu carga y su tendencia. Nunca un diagnóstico." },
    { n: "03", title: "Intervenir", body: "Cuando la carga sube, te propone ejercicios de 1 a 5 minutos: respiración, una pausa física o reordenar un pensamiento. Como máximo dos al día, y puedes silenciarlos." },
    { n: "04", title: "Evaluar", body: "Nos dices si te sirvió. Con eso ajustamos lo que te sugerimos y medimos si tu estrés baja con el tiempo." },
  ],
};

export const where = {
  eyebrow: "Dónde vive",
  title: "No tienes que salir de tu trabajo para saber cómo estás",
  places: [
    { name: "Extensión de VS Code", body: "El check-in aparece en la barra de estado, en una pausa natural: después de un commit, no en medio de una idea." },
    { name: "Agente de escritorio", body: "Para quien no vive en un solo editor. Discreto, con horas de silencio y modo foco." },
    { name: "App móvil", body: "Opcional. Para responder una escala con calma o ver tu semana fuera de la pantalla de trabajo." },
    { name: "Panel web", body: "Tu historial, tus permisos y tus datos, en un solo lugar." },
  ],
  statusBar: { brand: "selyh", question: "¿Cómo vas?", hint: "1 tranquilo · 5 sobrecargado" },
  notification: { title: "Selyh", body: "Llevas 3 h sin pausa. ¿Te estiras 1 minuto?" },
};

export const privacy = {
  eyebrow: "Tu privacidad",
  title: "Tus datos son tuyos. De verdad.",
  promises: [
    { title: "Permiso por cada fuente", body: "Check-ins, calendario, actividad del editor y wearables se activan por separado. Revocas uno y deja de usarse en el siguiente cálculo." },
    { title: "Solo números", body: "De tu editor solo llegan índices como horas activas. Nunca código, mensajes ni teclas." },
    { title: "Exporta o borra todo", body: "Descarga tus datos cuando quieras o borra tu cuenta por completo, como establece la Ley 29733." },
    { title: "Tu empresa no te ve a ti", body: "Solo ve tendencias de equipos con 5 personas o más. No existe una vista individual, y cada acceso queda registrado." },
  ],
  never: { label: "Lo que nunca recogemos", items: ["código fuente", "mensajes", "teclas", "nombres de archivos"] },
};

export const teams = {
  eyebrow: "Para equipos",
  title: "Detecta la sobrecarga del equipo a tiempo, sin exponer a nadie",
  body: "El panel corporativo muestra la tendencia de cada equipo para que actúes sobre las causas: guardias mal repartidas, semanas llenas de reuniones, deuda técnica que nadie prioriza. Nunca sobre personas.",
  points: ["Tendencias agregadas por equipo, mínimo 5 personas por métrica", "Invitaciones por correo y control de puestos", "Registro de auditoría de cada acceso"],
  chart: { title: "Carga media del equipo Plataforma", note: "Datos de ejemplo", threshold: "Equipo Móvil: 4 personas. Sin datos hasta llegar a 5." },
  cta: { label: "Pedir una demo", href: "#contacto" },
};

export const science = {
  eyebrow: "Respaldo científico",
  title: "Ciencia conocida, explicada sin jerga",
  intro: "No inventamos una métrica mágica. Usamos modelos y cuestionarios que la psicología usa desde hace años, y te decimos qué pueden y qué no pueden hacer.",
  items: [
    { term: "Demandas y recursos (JD-R)", body: "El estrés crece cuando lo que te pide el trabajo supera lo que tienes para responder: tiempo, apoyo, autonomía." },
    { term: "Preguntas en el momento", body: "Una pregunta corta en el momento recuerda mejor cómo estás que un cuestionario largo a fin de mes." },
    { term: "PSS-10", body: "Mide cuánto estrés has percibido en el último mes." },
    { term: "WHO-5", body: "Cinco preguntas de la OMS sobre tu bienestar en las últimas dos semanas." },
    { term: "PHQ-9 y GAD-7", body: "Tamizajes breves de ánimo y ansiedad. Orientan, no diagnostican." },
  ],
  limits: {
    title: "Lo que Selyh no es",
    body: "No es un dispositivo médico, no diagnostica y no reemplaza a un profesional. Las señales pasivas son indicadores indirectos, y nuestros umbrales se están validando en un piloto. Antes de tener 14 días de datos te mostramos “calibrando” en lugar de inventar un número.",
  },
};

export const formsSection = {
  eyebrow: "Hablemos",
  title: "Súmate, escríbenos o pide una demo",
  tabs: {
    WAITLIST: { label: "Lista de espera", intro: "Te avisamos cuando abramos la extensión y el agente de escritorio.", submit: "Unirme a la lista" },
    CONTACT: { label: "Contacto", intro: "¿Dudas, ideas o quieres colaborar? Te respondemos en pocos días.", submit: "Enviar mensaje" },
    DEMO: { label: "Demo para empresas", intro: "Te mostramos el panel de equipos con datos de ejemplo y conversamos sobre un piloto de 8 semanas.", submit: "Pedir demo" },
  },
  success: "Recibido. Gracias por escribirnos: te contactaremos pronto.",
};

export const finalCta = {
  title: "Tu línea base empieza con el primer check-in",
  body: "Crea tu cuenta gratis hoy. En dos semanas sabrás cómo es tu semana normal, y Selyh podrá avisarte cuando deje de serlo.",
  primary: { label: "Crear cuenta gratis", href: "/registro" },
  secondary: { label: "Pedir una demo para mi equipo", href: "#contacto" },
};

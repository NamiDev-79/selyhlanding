import { problem } from "@/content/landing";

import { SectionHead } from "./section-head";

/** Un día de trabajo como línea de tiempo: la carga sube con cada evento y no hay ninguna pausa. */
export function Problem() {
  const n = problem.day.events.length;
  return (
    <section aria-labelledby="problema" className="wrap grid gap-14 py-[var(--section)] lg:grid-cols-[1fr_1.05fr] lg:items-center lg:gap-20">
      <SectionHead id="problema" eyebrow={problem.eyebrow} title={problem.title}>
        <div className="grid max-w-[52ch] gap-4 text-step-0 text-ink-soft">
          {problem.body.map((p) => (
            <p key={p}>{p}</p>
          ))}
        </div>
      </SectionHead>

      <figure className="reveal card relative overflow-hidden p-6 sm:p-8">
        <div aria-hidden className="absolute -right-20 -top-20 size-64 rounded-full bg-warm-wash blur-2xl" />
        <figcaption className="relative mb-6 flex items-center justify-between">
          <span className="font-semibold">{problem.day.label}</span>
          <span className="eyebrow">carga acumulada</span>
        </figcaption>
        <ol className="relative grid gap-3">
          {problem.day.events.map((e, i) => {
            const load = ((i + 1) / n) * 100;
            return (
              <li key={e.time} className="grid grid-cols-[3.5rem_1fr] items-center gap-4 sm:grid-cols-[3.5rem_11rem_1fr]">
                <span className="figures text-sm text-ink-faint">{e.time}</span>
                <span className={`text-[0.95rem] ${i === n - 1 ? "font-semibold" : ""}`}>{e.text}</span>
                <span aria-hidden className="col-span-2 h-2 overflow-hidden rounded-full bg-paper-3 sm:col-span-1">
                  <span
                    className="block h-full rounded-full"
                    style={{ width: `${load}%`, background: `linear-gradient(90deg, var(--mint), ${i >= n - 2 ? "var(--warm)" : "var(--accent)"})` }}
                  />
                </span>
              </li>
            );
          })}
        </ol>
        <p className="relative mt-7 flex items-center justify-between gap-3 border-t border-line pt-5">
          <span className="font-display text-step-2 font-semibold">{problem.day.pause}</span>
          <span className="rounded-full bg-warm-wash px-3 py-1 text-sm font-medium text-warm-ink">sin aviso</span>
        </p>
      </figure>
    </section>
  );
}

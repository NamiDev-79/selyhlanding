"use client";

import { useState } from "react";

import { Icon } from "@/components/ui/icons";
import { TrendChart } from "@/components/ui/trend-chart";
import { hero } from "@/content/landing";
import { sampleTrend } from "@/content/sample-data";

// Valor del check-in → desvío respecto de la línea base que se dibuja como último punto (ejemplo).
const Z_FOR: Record<number, number> = { 1: -0.6, 2: -0.15, 3: 0.1, 4: 0.85, 5: 1.3 };
const BASE = sampleTrend.slice(0, 18);

const code = [
  [["k", "export async function "], ["f", "conciliar"], ["p", "(lote: Lote) {"]],
  [["p", "  const "], ["v", "pagos"], ["p", " = "], ["k", "await "], ["f", "obtenerPagos"], ["p", "(lote.id);"]],
  [["p", "  "], ["k", "return "], ["v", "pagos"], ["p", "."], ["f", "map"], ["p", "(redondear);"]],
  [["p", "}"]],
  [["c", ""]],
  [["c", "// ✓ commit: fix redondeo en conciliación"]],
] as const;

const tone = { k: "text-[oklch(78%_0.13_300)]", f: "text-[oklch(82%_0.11_200)]", v: "text-[oklch(88%_0.1_80)]", p: "text-[oklch(85%_0.01_280)]", c: "text-[oklch(62%_0.03_280)] italic" };

/** Demo de la portada: el check-in en la barra de estado del editor y la respuesta de Selyh. */
export function CheckinDemo() {
  const [value, setValue] = useState<number | null>(null);
  const [breathing, setBreathing] = useState(false);
  const d = hero.demo;
  const reply = value ? d.replies[value] : null;
  const values = value ? [...BASE, Z_FOR[value]!] : BASE;

  const choose = (n: number) => {
    setValue(n);
    setBreathing(false);
  };

  return (
    <div className="overflow-hidden rounded-[1.4rem] border border-line bg-paper shadow-float">
      <div className="flex items-center gap-1.5 border-b border-white/5 bg-night-2 px-4 py-3">
        {["bg-[oklch(70%_0.02_280)]", "bg-[oklch(60%_0.02_280)]", "bg-[oklch(50%_0.02_280)]"].map((c) => (
          <span key={c} className={`size-2.5 rounded-full ${c}`} />
        ))}
        <span className="ml-3 font-mono text-xs text-white/55">{d.file}</span>
      </div>

      <div className="grid lg:grid-cols-[1.15fr_1fr]">
        {/* Editor */}
        <div className="flex min-h-[19rem] min-w-0 flex-col bg-night text-[13px]">
          <pre className="flex-1 overflow-x-auto px-5 py-5 font-mono leading-7" aria-hidden>
            {code.map((line, i) => (
              <div key={i} className="flex gap-5">
                <span className="w-4 select-none text-right text-white/25">{41 + i}</span>
                <span>
                  {line.map(([t, txt], j) => (
                    <span key={j} className={tone[t]}>
                      {txt}
                    </span>
                  ))}
                </span>
              </div>
            ))}
          </pre>
          <div className="flex flex-wrap items-center gap-x-3 gap-y-2 bg-accent-strong px-3 py-2 font-mono text-[12px] text-white">
            <span className="flex items-center gap-1.5">
              <span aria-hidden className="breathe size-2 rounded-full bg-mint" />
              selyh
            </span>
            <span id="demo-q">{d.question}</span>
            <div role="group" aria-labelledby="demo-q" className="flex gap-1">
              {[1, 2, 3, 4, 5].map((n) => (
                <button
                  key={n}
                  type="button"
                  aria-pressed={value === n}
                  aria-label={`${n}, ${d.scale[n - 1]}`}
                  onClick={() => choose(n)}
                  className={`grid size-7 place-items-center rounded-md border text-[12px] font-semibold transition-all ${
                    value === n ? "scale-110 border-white bg-white text-accent-strong" : "border-white/35 hover:border-white hover:bg-white/15"
                  } ${value == null ? "animate-pulse" : ""}`}
                  style={value == null ? { animationDelay: `${n * 120}ms` } : undefined}
                >
                  {n}
                </button>
              ))}
            </div>
            <span className="ml-auto hidden text-white/70 sm:inline">main ↑1</span>
          </div>
        </div>

        {/* Respuesta de Selyh */}
        <div className="grid min-w-0 content-start gap-4 border-t border-line bg-paper p-5 lg:border-l lg:border-t-0">
          <div className="flex items-baseline justify-between gap-3">
            <span className="text-sm font-semibold">{hero.chart.title}</span>
            <span className="eyebrow">{hero.chart.note}</span>
          </div>
          <TrendChart
            values={values}
            bandLabel={hero.chart.bandLabel}
            labels={["hace 3 semanas", "hoy"]}
            ariaLabel="Gráfico de ejemplo: la carga de las últimas semanas frente al rango habitual; el último punto cambia con el check-in elegido."
            height={190}
          />
          <div aria-live="polite" className="min-h-[7.5rem]">
            {reply ? (
              <div key={value} className={`pop grid gap-2 rounded-xl border p-4 ${value! >= 4 ? "border-warm/50 bg-warm-wash" : "border-mint/60 bg-mint-wash"}`}>
                <p className="font-semibold leading-snug">{reply.title}</p>
                <p className="text-sm text-ink-soft">{reply.body}</p>
                {value! >= 4 ? (
                  breathing ? (
                    <div className="mt-1 flex items-center gap-3 text-sm font-medium text-warm-ink">
                      <span aria-hidden className="breathe size-6 rounded-full bg-warm" style={{ animationDuration: "8s" }} />
                      Inhala 4 s · exhala 4 s
                    </div>
                  ) : (
                    <button type="button" onClick={() => setBreathing(true)} className="mt-1 inline-flex w-fit items-center gap-1.5 text-sm font-semibold text-ink hover:underline">
                      <Icon name="wind" className="size-4" /> {d.action}
                    </button>
                  )
                ) : null}
              </div>
            ) : (
              <div className="flex h-full items-center gap-3 rounded-xl border border-dashed border-line-strong p-4 text-sm text-ink-soft">
                <span aria-hidden className="breathe size-2.5 shrink-0 rounded-full bg-accent" />
                {d.hint} en la barra del editor.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

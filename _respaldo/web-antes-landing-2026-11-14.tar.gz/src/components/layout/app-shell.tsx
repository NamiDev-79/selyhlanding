"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import type { ReactNode } from "react";

import { crisis } from "@/content/crisis";

import { LogoutButton } from "./logout-button";
import { Wordmark } from "./wordmark";

type NavItem = { href: string; label: string };

/** Shell del panel: navegación lateral sobria en escritorio, desplazable en móvil. */
export function AppShell({ nav, title, aside, switcher, children }: { nav: readonly NavItem[]; title: string; aside?: ReactNode; switcher?: NavItem; children: ReactNode }) {
  const pathname = usePathname();
  const root = nav[0]!.href;
  const isActive = (href: string) => (href === root ? pathname === href : pathname === href || pathname.startsWith(href + "/"));

  return (
    <div className="min-h-dvh lg:grid lg:grid-cols-[15.5rem_1fr]">
      <aside className="border-b border-line bg-paper-2 lg:sticky lg:top-0 lg:h-dvh lg:border-b-0 lg:border-r">
        <div className="flex h-16 items-center justify-between px-5 lg:h-20">
          <Wordmark href={root} />
          <span className="eyebrow lg:hidden">{title}</span>
        </div>
        <nav aria-label={title} className="overflow-x-auto px-3 pb-3 lg:overflow-visible lg:pb-0">
          <p className="eyebrow hidden px-2 pb-2 lg:block">{title}</p>
          <ul className="flex gap-1 lg:grid lg:gap-0.5">
            {nav.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  aria-current={isActive(item.href) ? "page" : undefined}
                  className="block whitespace-nowrap rounded-ui px-2.5 py-1.5 text-[0.93rem] text-ink-soft transition-colors hover:bg-paper-3 hover:text-ink aria-[current=page]:bg-paper aria-[current=page]:font-medium aria-[current=page]:text-ink aria-[current=page]:shadow-[inset_2px_0_0_var(--accent)]"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <div className="hidden gap-4 px-5 pt-8 lg:grid">
          {switcher ? (
            <Link href={switcher.href} className="link text-[0.93rem]">
              {switcher.label} →
            </Link>
          ) : null}
          {aside}
          <p className="text-step--1 text-ink-faint">
            ¿Mal momento? <a className="link" href={crisis.resources[0]!.href}>Línea 113, opción 5</a>
          </p>
          <LogoutButton className="justify-start px-0!" />
        </div>
      </aside>
      <div className="min-w-0">
        <main id="contenido" className="mx-auto w-full max-w-5xl px-[var(--gutter)] py-[clamp(2rem,1.5rem+2vw,3.5rem)]">
          {children}
        </main>
        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-line px-[var(--gutter)] py-4 lg:hidden">
          {switcher ? (
            <Link href={switcher.href} className="link text-[0.93rem]">
              {switcher.label} →
            </Link>
          ) : <span />}
          <LogoutButton />
        </div>
      </div>
    </div>
  );
}

export function PageHeader({ title, lead, eyebrow, actions }: { title: string; lead?: ReactNode; eyebrow?: string; actions?: ReactNode }) {
  return (
    <header className="mb-10 flex flex-wrap items-end justify-between gap-6 border-b border-line pb-6">
      <div className="grid max-w-2xl gap-2">
        {eyebrow ? <p className="eyebrow">{eyebrow}</p> : null}
        <h1 className="text-step-4">{title}</h1>
        {lead ? <div className="text-ink-soft">{lead}</div> : null}
      </div>
      {actions}
    </header>
  );
}

export function Section({ title, description, children, className = "" }: { title: string; description?: ReactNode; children: ReactNode; className?: string }) {
  return (
    <section className={`grid gap-5 ${className}`}>
      <div className="grid gap-1">
        <h2 className="text-step-2">{title}</h2>
        {description ? <div className="max-w-2xl text-step--1 text-ink-soft">{description}</div> : null}
      </div>
      {children}
    </section>
  );
}

"use client";

import { GitBranch } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";

import { PauseBars } from "@/components/brand/logo";
import { hero } from "@/content/landing";
import { cn } from "@/lib/utils";

import { EASE } from "./primitives";

/* Código de ejemplo con resaltado sobrio: palabras clave en índigo suave, cadenas en lila claro. */
const K = ({ children }: { children: string }) => <span className="text-[#A2A2FA]">{children}</span>;
const S = ({ children }: { children: string }) => <span className="text-[#C7C7FA]">{children}</span>;
const F = ({ children }: { children: string }) => <span className="text-white">{children}</span>;
const C = ({ children }: { children: string }) => <span className="text-[#7C8494]">{children}</span>;

const code = [
  <><C>{"// reintenta el cobro si la pasarela lo rechaza"}</C></>,
  <><K>export async function</K> <F>cobrar</F>(pedido: Pedido) {"{"}</>,
  <>{"  "}<K>const</K> intento = <K>await</K> pasarela.<F>crear</F>({"{"}</>,
  <>{"    "}monto: pedido.total,</>,
  <>{"    "}moneda: <S>{'"PEN"'}</S>,</>,
  <>{"  "}{"});"}</>,
  <>{"  "}<K>if</K> (intento.estado === <S>{'"rechazado"'}</S>) {"{"}</>,
  <>{"    "}<K>return</K> <F>reintentar</F>(pedido, {"{ max: 3 }"});</>,
  <>{"  }"}</>,
  <>{"  "}<K>return</K> <F>registrar</F>(intento);</>,
  <>{"}"}</>,
];

const SCALE = [1, 2, 3, 4, 5] as const;

/**
 * Demo de la portada: un editor con el check-in de Selyh en una pausa natural (después de un commit).
 * Es interactiva: al elegir un número aparece la respuesta que daría Selyh.
 * El editor es siempre oscuro, como un IDE, en ambos temas de la página.
 */
export function CheckinEditor() {
  const [value, setValue] = useState<number | null>(null);
  const reply = value ? hero.demo.replies[value] : null;

  return (
    <div className="relative overflow-hidden rounded-[22px] border border-white/10 bg-[#0F1523] text-[13px] text-white/75 shadow-[0_40px_80px_-40px_rgb(15_21_35/0.55)] ring-1 ring-black/5">
      {/* Pestañas */}
      <div className="flex items-end gap-1 border-b border-white/[0.07] bg-[#0B101B] px-3 pt-2.5">
        <span className="rounded-t-lg border border-b-0 border-white/[0.07] bg-[#0F1523] px-3.5 py-2 text-[12.5px] text-white">servicio.ts</span>
        <span className="px-3.5 py-2 text-[12.5px] text-white/45">pedido.ts</span>
        <span className="ml-auto hidden pb-2 text-[12px] text-white/60 sm:block">{hero.demo.file}</span>
      </div>

      {/* Código */}
      <div className="grid grid-cols-[2.25rem_minmax(0,1fr)] overflow-hidden py-4 font-[ui-monospace,SFMono-Regular,Menlo,Consolas,monospace] text-[11.5px] leading-[1.75] sm:text-[12.5px]" aria-hidden>
        <div className="select-none pr-3 text-right text-white/50 tabular">
          {code.map((_, i) => (
            <div key={i}>{i + 1}</div>
          ))}
        </div>
        <div className="overflow-hidden whitespace-pre text-white/70">
          {code.map((line, i) => (
            <div key={i} className={cn(i === 7 && "-mx-2 rounded bg-white/[0.04] px-2")}>
              {line}
            </div>
          ))}
        </div>
      </div>

      {/* Check-in de Selyh */}
      <div className="px-3 pb-3 sm:absolute sm:bottom-12 sm:right-4 sm:w-[19.5rem] sm:p-0">
        <div role="group" aria-labelledby="demo-pregunta" className="rounded-2xl border border-white/10 bg-[#1B2232] p-4 shadow-[0_20px_40px_-20px_rgb(0_0_0/0.6)]">
          <div className="flex items-center justify-between gap-3">
            <p id="demo-pregunta" className="flex items-center gap-2 font-display text-[15px] font-semibold text-white">
              <PauseBars className="h-3.5 w-auto" />
              {hero.demo.question}
            </p>
            <span className="text-[11.5px] text-white/50">después de tu commit</span>
          </div>

          <div className="mt-3 grid grid-cols-5 gap-1.5">
            {SCALE.map((n) => (
              <button
                key={n}
                type="button"
                aria-pressed={value === n}
                aria-label={`${n}: ${hero.demo.scale[n - 1]}`}
                onClick={() => setValue(n)}
                className={cn(
                  "h-10 rounded-[10px] border text-[15px] font-semibold tabular transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#A2A2FA]",
                  value === n ? "border-[#6363F1] bg-[#6363F1] text-white" : "border-white/10 bg-white/[0.03] text-white/80 hover:border-white/25 hover:text-white",
                )}
              >
                {n}
              </button>
            ))}
          </div>
          <div className="mt-1.5 flex justify-between text-[11.5px] text-white/50">
            <span>{hero.demo.scale[0]}</span>
            <span>{hero.demo.scale[4]}</span>
          </div>

          <div aria-live="polite" className="min-h-[4.25rem]">
            <AnimatePresence mode="wait" initial={false}>
              {reply ? (
                <motion.div
                  key={value}
                  initial={{ opacity: 0, y: 6 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  transition={{ duration: 0.3, ease: EASE }}
                  className="mt-3 border-t border-white/[0.08] pt-3"
                >
                  <p className="text-[13px] font-medium text-white">{reply.title}</p>
                  <p className="mt-0.5 text-[12.5px] leading-relaxed text-white/60">{reply.body}</p>
                  {value && value >= 4 ? (
                    <span className="mt-2.5 inline-flex h-8 items-center rounded-full bg-[#6363F1] px-3.5 text-[12.5px] font-medium text-white">{hero.demo.action}</span>
                  ) : null}
                </motion.div>
              ) : (
                <motion.p key="hint" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="mt-3 border-t border-white/[0.08] pt-3 text-[12.5px] text-white/55">
                  {hero.demo.hint}.
                </motion.p>
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Barra de estado */}
      <div className="flex items-center justify-between gap-3 border-t border-white/[0.07] bg-[#0B101B] px-3.5 py-2 text-[11.5px] text-white/55">
        <span className="flex items-center gap-1.5">
          <GitBranch className="size-3.5" aria-hidden />
          main
        </span>
        <span className="flex items-center gap-1.5 text-white/70">
          <PauseBars className="h-3 w-auto" />
          selyh · línea base calibrada
        </span>
      </div>
    </div>
  );
}

/** Datos generales de la marca. Edita aquí nombre, lema, contacto y navegación. */
export const site = {
  name: "Selyh",
  tagline: "Cuida tu salud mental sin salir de tu flujo de trabajo",
  description:
    "Selyh ayuda a desarrolladores y equipos de software a notar a tiempo la sobrecarga: check-ins de un toque desde el IDE, tu propia línea base y pausas breves que sí sirven. Sin vigilancia y con tus datos bajo tu control.",
  url: process.env.SITE_URL ?? "http://localhost:5173",
  locale: "es_PE",
  email: "hola@selyh.app",
  city: "Trujillo, Perú",
  nav: [
    { href: "/#como-funciona", label: "Cómo funciona" },
    { href: "/#privacidad", label: "Privacidad" },
    { href: "/#equipos", label: "Equipos" },
    { href: "/precios", label: "Planes" },
    { href: "/#preguntas", label: "Preguntas" },
  ],
} as const;

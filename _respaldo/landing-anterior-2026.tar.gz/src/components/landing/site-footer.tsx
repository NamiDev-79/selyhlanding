import { ArrowUpRight } from "lucide-react";
import Link from "next/link";

import { Logo } from "@/components/brand/logo";
import { crisis } from "@/content/crisis";
import { site } from "@/content/site";

import { Wrap } from "./primitives";

const links = [
  { href: "/#como-funciona", label: "Cómo funciona" },
  { href: "/#planes", label: "Planes" },
  { href: "/hans-selye", label: "Hans Selye" },
  { href: "/privacidad", label: "Privacidad" },
  { href: "/terminos", label: "Términos" },
  { href: "/#contacto", label: "Contacto" },
];

export function SiteFooter() {
  return (
    <footer className="border-t border-border bg-surface-raised">
      <Wrap className="grid gap-12 py-16 md:grid-cols-[minmax(0,1.2fr)_minmax(0,0.8fr)_minmax(0,1.4fr)]">
        <div className="grid content-start gap-5">
          <Link href="/" aria-label="Selyh, inicio" className="w-fit text-foreground">
            <Logo className="h-7" />
          </Link>
          <p className="max-w-xs text-[0.875rem] text-muted-foreground">
            {site.tagline}. Hecho por un equipo de cuatro en {site.city}.
          </p>
          <ul className="grid gap-1.5 text-[0.9375rem]">
            <li>
              <a className="text-brand-strong underline decoration-brand-soft underline-offset-4 hover:decoration-current" href={`mailto:${site.email}`}>
                {site.email}
              </a>
            </li>
            {site.social.map((s) => (
              <li key={s.href}>
                <a href={s.href} target="_blank" rel="noreferrer" className="group inline-flex items-center gap-1 text-muted-foreground transition-colors hover:text-foreground">
                  {s.label} <span className="text-foreground/70">{s.handle}</span>
                  <ArrowUpRight className="size-3.5 transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" aria-hidden />
                  <span className="sr-only">(se abre en otra pestaña)</span>
                </a>
              </li>
            ))}
          </ul>
        </div>

        <nav aria-label="Pie de página" className="grid content-start gap-2.5 text-[0.9375rem]">
          <p className="mb-1 text-[0.8125rem] font-medium uppercase tracking-[0.08em] text-muted-foreground">Selyh</p>
          {links.map((l) => (
            <Link key={l.href} className="w-fit text-muted-foreground transition-colors hover:text-foreground" href={l.href}>
              {l.label}
            </Link>
          ))}
        </nav>

        <section aria-labelledby="ayuda-crisis" className="grid content-start gap-3 rounded-2xl border border-border bg-background p-[26px]">
          <h2 id="ayuda-crisis" className="font-sans text-[1rem] font-semibold tracking-normal">
            {crisis.title}
          </h2>
          <p className="text-[0.875rem] text-muted-foreground">{crisis.body}</p>
          <ul className="grid gap-1.5 text-[0.9375rem]">
            {crisis.resources.map((r) => (
              <li key={r.name} className="flex flex-wrap items-baseline justify-between gap-x-4 border-b border-border pb-1.5 last:border-b-0">
                <a href={r.href} className="font-medium text-foreground hover:text-brand-strong">
                  {r.name}
                </a>
                <span className="text-[0.8125rem] text-muted-foreground">{r.detail}</span>
              </li>
            ))}
          </ul>
        </section>
      </Wrap>
      <Wrap>
        <div className="flex flex-wrap justify-between gap-2 border-t border-border py-5 text-[0.8125rem] text-muted-foreground">
          <p>© 2026 Selyh. No es un dispositivo médico ni reemplaza a un profesional.</p>
          <p>{site.city}</p>
        </div>
      </Wrap>
    </footer>
  );
}

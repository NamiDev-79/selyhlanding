import { LinkButton } from "@/components/ui/button";
import { Icon } from "@/components/ui/icons";
import { finalCta } from "@/content/landing";

/** Cierre de la landing: una última invitación clara antes del pie. */
export function FinalCta() {
  return (
    <section aria-labelledby="cta-final" className="wrap pt-[var(--section)]">
      <div className="reveal relative isolate overflow-hidden rounded-[2rem] bg-gradient-to-br from-accent-strong via-[oklch(50%_0.2_295)] to-[oklch(55%_0.14_200)] px-6 py-16 text-center text-white sm:px-12 sm:py-20">
        <div aria-hidden className="dots absolute inset-0 -z-10 opacity-30 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)] invert" />
        <div aria-hidden className="breathe absolute left-1/2 top-1/2 -z-10 size-[28rem] -translate-x-1/2 -translate-y-1/2 rounded-full border border-white/15" />
        <h2 id="cta-final" className="mx-auto max-w-[18ch] text-step-4">
          {finalCta.title}
        </h2>
        <p className="mx-auto mt-5 max-w-[52ch] text-step-1 text-white/80">{finalCta.body}</p>
        <div className="mt-9 flex flex-wrap justify-center gap-3">
          <LinkButton href={finalCta.primary.href} size="lg" className="bg-white! text-accent-strong! shadow-float hover:bg-white/90!">
            {finalCta.primary.label}
            <Icon name="arrow" className="size-4" />
          </LinkButton>
          <LinkButton href={finalCta.secondary.href} size="lg" variant="ghost" className="text-white! ring-1 ring-white/40 hover:bg-white/10!">
            {finalCta.secondary.label}
          </LinkButton>
        </div>
      </div>
    </section>
  );
}

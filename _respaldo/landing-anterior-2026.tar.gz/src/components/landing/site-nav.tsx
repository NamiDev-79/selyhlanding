"use client";

import { Menu } from "lucide-react";
import { motion, useMotionValueEvent, useScroll } from "motion/react";
import Link from "next/link";
import { useEffect, useState } from "react";

import { AnimatedLogo } from "@/components/brand/animated-logo";
import { Button } from "@/components/shadcn/button";
import { Sheet, SheetClose, SheetContent, SheetDescription, SheetTitle, SheetTrigger } from "@/components/shadcn/sheet";
import { site } from "@/content/site";
import { panelHref } from "@/features/auth/session-cta";
import { bff } from "@/lib/api/client";
import { cn } from "@/lib/utils";

import { ThemeToggle } from "./theme-toggle";

type Session = { authenticated: false } | { authenticated: true; user: { name: string; role: string; onboardingState: string } };

/** La sesión se consulta en el navegador para que la landing siga siendo estática. */
function useSession() {
  const [session, setSession] = useState<Session | null>(null);
  useEffect(() => {
    bff<Session>("/api/auth/session")
      .then(setSession)
      .catch(() => setSession({ authenticated: false }));
  }, []);
  return session;
}

/**
 * Barra de navegación de vidrio, flotante, al estilo iOS: desenfoque y saturación del contenido
 * que pasa por debajo, borde fino y brillo superior. Se compacta un poco al hacer scroll.
 */
export function SiteNav() {
  const session = useSession();
  const { scrollY } = useScroll();
  const [scrolled, setScrolled] = useState(false);
  useMotionValueEvent(scrollY, "change", (y) => setScrolled(y > 12));

  const panel = session?.authenticated ? { href: panelHref(session.user), label: "Ir a mi panel" } : null;

  return (
    <header className="pointer-events-none sticky top-0 z-40 px-3 pt-3 sm:px-4">
      <motion.div
        initial={{ y: -16, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
        className={cn(
          "glass pointer-events-auto mx-auto flex h-14 max-w-[68rem] items-center justify-between gap-3 rounded-full pl-5 pr-2 transition-[max-width] duration-500 ease-[cubic-bezier(.22,1,.36,1)]",
          scrolled && "max-w-[62rem]",
        )}
      >
        <Link href="/" aria-label="Selyh, inicio" className="flex items-center rounded-md text-foreground focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ring">
          <AnimatedLogo className="h-[1.45rem]" breathe={false} />
        </Link>

        <nav aria-label="Principal" className="hidden items-center lg:flex">
          {site.nav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-full px-3.5 py-2 text-[0.9375rem] text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-1">
          <ThemeToggle />
          <div className={cn("flex items-center gap-1 transition-opacity duration-300", session ? "opacity-100" : "opacity-0")}>
            {panel ? (
              <Button asChild size="sm">
                <Link href={panel.href}>{panel.label}</Link>
              </Button>
            ) : (
              <>
                <Button asChild variant="ghost" size="sm" className="max-sm:hidden">
                  <Link href="/login">Iniciar sesión</Link>
                </Button>
                <Button asChild size="sm" className="max-[380px]:hidden">
                  <Link href="/registro">Crear cuenta</Link>
                </Button>
              </>
            )}
          </div>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="lg:hidden" aria-label="Abrir menú">
                <Menu className="size-5" aria-hidden />
              </Button>
            </SheetTrigger>
            <SheetContent className="glass">
              <SheetTitle>Menú</SheetTitle>
              <SheetDescription>Secciones de la página y acceso a tu cuenta.</SheetDescription>
              <nav aria-label="Principal (móvil)" className="grid gap-1 pt-12">
                {site.nav.map((item) => (
                  <SheetClose asChild key={item.href}>
                    <Link href={item.href} className="rounded-2xl px-4 py-3 font-display text-2xl font-semibold tracking-[-0.02em] text-foreground transition-colors hover:bg-muted">
                      {item.label}
                    </Link>
                  </SheetClose>
                ))}
              </nav>
              <div className="mt-4 grid gap-2 border-t border-border pt-4 sm:grid-cols-2">
                {panel ? (
                  <Button asChild size="lg">
                    <Link href={panel.href}>{panel.label}</Link>
                  </Button>
                ) : (
                  <>
                    <Button asChild size="lg">
                      <Link href="/registro">Crear cuenta gratis</Link>
                    </Button>
                    <Button asChild size="lg" variant="outline">
                      <Link href="/login">Iniciar sesión</Link>
                    </Button>
                  </>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </motion.div>
    </header>
  );
}

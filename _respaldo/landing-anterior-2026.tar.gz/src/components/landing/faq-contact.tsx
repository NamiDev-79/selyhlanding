"use client";

import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/shadcn/accordion";
import { faq } from "@/content/faq";
import { formsSection } from "@/content/landing";
import { LeadForms } from "@/features/leads/lead-forms";

import { Eyebrow, Reveal, SectionTitle, Wrap } from "./primitives";

/** Preguntas frecuentes (acordeón accesible de shadcn/Radix). */
export function Faq() {
  return (
    <section id="preguntas" aria-labelledby="preguntas-title" className="scroll-mt-24 py-[clamp(4.5rem,3rem+5vw,7rem)]">
      <Wrap className="grid gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.618fr)] lg:gap-[68px]">
        <Reveal className="grid content-start gap-[26px] lg:sticky lg:top-28 lg:self-start">
          <Eyebrow n="08">{faq.eyebrow}</Eyebrow>
          <SectionTitle id="preguntas-title">{faq.title}</SectionTitle>
        </Reveal>
        <Reveal delay={0.08}>
          <Accordion type="single" collapsible className="border-t border-border">
            {faq.items.map((item, i) => (
              <AccordionItem key={item.q} value={`q${i}`}>
                <AccordionTrigger>{item.q}</AccordionTrigger>
                <AccordionContent className="text-[1rem] leading-[1.65]">{item.a}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </Reveal>
      </Wrap>
    </section>
  );
}

/** Lista de espera, contacto y demo para empresas (formularios existentes, POST /public/leads). */
export function Contact() {
  return (
    <section id="contacto" aria-labelledby="contacto-title" className="scroll-mt-24 pb-[clamp(4.5rem,3rem+5vw,7rem)]">
      <Wrap>
        <div className="grid gap-12 border-t border-border pt-[clamp(3rem,2rem+3vw,4.5rem)] lg:grid-cols-[minmax(0,1fr)_minmax(0,1.618fr)] lg:gap-[68px]">
          <Reveal className="grid content-start gap-[26px]">
            <Eyebrow n="09">{formsSection.eyebrow}</Eyebrow>
            <SectionTitle id="contacto-title">{formsSection.title}</SectionTitle>
          </Reveal>
          <Reveal delay={0.08} className="rounded-2xl border border-border bg-background p-[26px] sm:p-[42px]">
            <LeadForms />
          </Reveal>
        </div>
      </Wrap>
    </section>
  );
}

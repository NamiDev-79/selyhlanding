"use client";

import { motion, type HTMLMotionProps } from "motion/react";
import type { ReactNode } from "react";

import { cn } from "@/lib/utils";

/** Curva de la marca (ease-out suave). Nada de rebotes en la interfaz: calma, no alarma. */
export const EASE = [0.22, 1, 0.36, 1] as const;

/** Aparece una sola vez al entrar en pantalla. Con movimiento reducido, MotionConfig lo deja quieto. */
export function Reveal({ children, delay = 0, y = 18, className, ...rest }: { children: ReactNode; delay?: number; y?: number } & HTMLMotionProps<"div">) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.25 }}
      transition={{ duration: 0.7, ease: EASE, delay }}
      className={className}
      {...rest}
    >
      {children}
    </motion.div>
  );
}

/** Rótulo de sección: número + nombre en mayúsculas pequeñas, como en el manual de marca. */
export function Eyebrow({ n, children, className }: { n?: string; children: ReactNode; className?: string }) {
  return (
    <p className={cn("flex items-center gap-3 text-[0.8125rem] font-medium uppercase tracking-[0.08em] text-brand-strong", className)}>
      {n ? <span className="tabular text-muted-foreground">{n}</span> : null}
      {n ? <span aria-hidden className="h-px w-6 bg-current opacity-40" /> : null}
      {children}
    </p>
  );
}

/** Titular de sección (Bricolage 700). Tamaños de la escala áurea: 26 → 42 px. */
export function SectionTitle({ id, children, className }: { id?: string; children: ReactNode; className?: string }) {
  return (
    <h2 id={id} className={cn("max-w-[22ch] font-display text-[clamp(1.75rem,1.2rem+2.2vw,2.625rem)] leading-[1.1] text-foreground", className)}>
      {children}
    </h2>
  );
}

/** Contenedor de página: ancho máximo y márgenes laterales fluidos. */
export function Wrap({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn("mx-auto w-full max-w-[76rem] px-[clamp(1.25rem,0.6rem+2.6vw,2.5rem)]", className)}>{children}</div>;
}

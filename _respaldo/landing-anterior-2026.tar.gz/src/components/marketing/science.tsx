import Link from "next/link";

import { Icon } from "@/components/ui/icons";
import { science } from "@/content/landing";

import { SectionHead } from "./section-head";

export function Science() {
  return (
    <section aria-labelledby="ciencia" className="bg-paper-2 py-[var(--section)]">
      <div className="wrap">
        <SectionHead id="ciencia" eyebrow={science.eyebrow} title={science.title} center>
          <p className="max-w-[56ch] text-ink-soft">{science.intro}</p>
        </SectionHead>
        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <dl className="contents">
            {science.items.map((item, i) => (
              <div key={item.term} className={`reveal ${i === 0 ? "sm:col-span-2 lg:col-span-1 lg:row-span-2" : ""}`}>
                <div className={`card grid h-full content-start gap-3 p-6 ${i === 0 ? "bg-gradient-to-b from-accent-wash to-paper" : ""}`}>
                  <Icon name="book" className="size-5 text-accent-strong" />
                  <dt className={`font-display font-semibold ${i === 0 ? "text-step-2" : "text-step-1"}`}>{item.term}</dt>
                  <dd className="text-[0.95rem] text-ink-soft">{item.body}</dd>
                </div>
              </div>
            ))}
          </dl>
          <aside className="reveal sm:col-span-2 lg:col-span-3">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid h-full content-start gap-2 rounded-2xl border border-line bg-paper p-6">
                <span className="eyebrow text-accent-strong">Inspiración y raíces</span>
                <h3 className="font-display text-step-1 font-semibold tracking-tight text-ink">
                  El legado del Dr. Hans Selye (1907 – 1982)
                </h3>
                <p className="text-[0.95rem] text-ink-soft">
                  El médico y endocrinólogo que formuló el Síndrome General de Adaptación y acuñó el concepto moderno de estrés. Descubre por qué nos llamamos Selyh.
                </p>
                <div>
                  <Link href="/hans-selye" className="link mt-2 inline-flex items-center gap-1.5 text-step--1 font-medium text-accent-strong">
                    Leer biografía y cómo nos inspira <span aria-hidden>→</span>
                  </Link>
                </div>
              </div>

              <div className="grid h-full content-start gap-2 rounded-2xl border border-warm/40 bg-warm-wash p-6">
                <h3 className="font-sans text-base font-semibold tracking-normal">{science.limits.title}</h3>
                <p className="text-[0.95rem] text-ink-soft">{science.limits.body}</p>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

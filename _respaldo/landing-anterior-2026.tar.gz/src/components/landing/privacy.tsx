"use client";

import { motion } from "motion/react";

import { privacy } from "@/content/landing";

import { EASE, Reveal, Wrap } from "./primitives";

/**
 * Privacidad: banda en azul tinta (siempre oscura, también en modo claro). Es el valor n.º 1 de la marca,
 * así que tiene el único bloque de contraste fuerte de la página.
 */
export function Privacy() {
  return (
    <section id="privacidad" aria-labelledby="privacidad-title" className="scroll-mt-24 px-3 sm:px-4">
      <div className="mx-auto max-w-[80rem] rounded-[32px] bg-[var(--band)] py-[clamp(4rem,3rem+4vw,6.5rem)] text-white ring-1 ring-white/[0.06]">
        <Wrap className="grid gap-14 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.618fr)] lg:gap-[68px]">
          <Reveal className="grid content-start gap-[26px]">
            <p className="flex items-center gap-3 text-[0.8125rem] font-medium uppercase tracking-[0.08em] text-[#C7C7FA]">
              <span className="tabular text-white/50">04</span>
              <span aria-hidden className="h-px w-6 bg-current opacity-40" />
              {privacy.eyebrow}
            </p>
            <h2 id="privacidad-title" className="max-w-[14ch] font-display text-[clamp(2rem,1.3rem+2.6vw,3.25rem)] leading-[1.05] text-white">
              {privacy.title}
            </h2>
            <div className="mt-2 grid gap-3">
              <p className="text-[0.9375rem] text-white/65">{privacy.never.label}</p>
              <ul className="flex flex-wrap gap-2">
                {privacy.never.items.map((item) => (
                  <li key={item} className="rounded-full border border-white/15 px-3 py-1.5 text-[0.875rem] text-white/80 line-through decoration-[#A2A2FA] decoration-[1.5px]">
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          </Reveal>

          <dl className="grid gap-x-10 sm:grid-cols-2">
            {privacy.promises.map((p, i) => (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.4 }}
                transition={{ duration: 0.6, ease: EASE, delay: i * 0.07 }}
                className="grid content-start gap-2.5 border-t border-white/12 py-7"
              >
                <dt className="font-display text-xl font-bold tracking-[-0.01em] text-white">{p.title}</dt>
                <dd className="text-[0.9375rem] leading-relaxed text-white/70">{p.body}</dd>
              </motion.div>
            ))}
          </dl>
        </Wrap>
      </div>
    </section>
  );
}

"use client";

import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Notice } from "@/components/ui/feedback";
import { checkinCopy } from "@/content/panel";
import { ApiError, errorText } from "@/lib/api/client";
import { useSetConsent } from "@/features/privacy/hooks";

import { type Tag, useCreateCheckin } from "./hooks";

/** Check-in de un toque: cinco círculos, el elegido respira despacio. */
export function QuickCheckin() {
  const [score, setScore] = useState<number | null>(null);
  const [tag, setTag] = useState<Tag | undefined>();
  const create = useCreateCheckin();
  const consent = useSetConsent();
  const c = checkinCopy;
  const needsConsent = create.error instanceof ApiError && create.error.code === "CONSENT_REQUIRED";

  const save = (value: number) => create.mutate({ score: value, tag });

  return (
    <section aria-labelledby="checkin-q" className="grid gap-6">
      <h2 id="checkin-q" className="text-step-3">
        {c.question}
      </h2>
      <div role="radiogroup" aria-labelledby="checkin-q" className="grid grid-cols-5 gap-2 sm:max-w-md">
        {c.scale.map((s) => {
          const selected = score === s.value;
          return (
            <button
              key={s.value}
              type="button"
              role="radio"
              aria-checked={selected}
              aria-label={`${s.value}: ${s.label}`}
              disabled={create.isPending}
              onClick={() => {
                setScore(s.value);
                save(s.value);
              }}
              className="group grid justify-items-center gap-2 py-1"
            >
              <span className="relative grid size-12 place-items-center sm:size-14">
                {selected ? <span aria-hidden className="breathe absolute inset-0 rounded-full bg-accent/30" /> : null}
                <span
                  className={`relative grid size-10 place-items-center rounded-full border font-mono text-sm transition-colors sm:size-11 ${
                    selected ? "border-accent-strong bg-accent-strong text-on-accent" : "border-line-strong bg-paper text-ink group-hover:border-ink"
                  }`}
                >
                  {s.value}
                </span>
              </span>
              <span className={`text-center text-[0.72rem] leading-tight ${selected ? "text-ink" : "text-ink-faint"}`}>{s.label}</span>
            </button>
          );
        })}
      </div>

      <fieldset className="grid gap-2">
        <legend className="mb-1 text-step--1 text-ink-soft">{c.tagsLabel}</legend>
        <div className="flex flex-wrap gap-1.5">
          {c.tags.map((t) => (
            <button
              key={t.value}
              type="button"
              aria-pressed={tag === t.value}
              onClick={() => setTag(tag === t.value ? undefined : (t.value as Tag))}
              className="rounded-full border border-line-strong px-3 py-1 text-sm text-ink-soft transition-colors hover:border-ink aria-pressed:border-accent-strong aria-pressed:bg-accent-wash aria-pressed:text-ink"
            >
              {t.label}
            </button>
          ))}
        </div>
      </fieldset>

      <div aria-live="polite" className="min-h-6">
        {create.isSuccess ? <p className="text-accent-strong">{c.saved}</p> : null}
        {needsConsent ? (
          <Notice tone="attention" title={c.consent}>
            <Button
              size="sm"
              className="mt-2"
              pending={consent.isPending}
              onClick={() => consent.mutate({ source: "CHECKIN", granted: true }, { onSuccess: () => score && save(score) })}
            >
              {c.consentAction}
            </Button>
          </Notice>
        ) : create.isError ? (
          <p role="alert" className="text-warm-ink">
            {errorText(create.error)}
          </p>
        ) : null}
      </div>
    </section>
  );
}

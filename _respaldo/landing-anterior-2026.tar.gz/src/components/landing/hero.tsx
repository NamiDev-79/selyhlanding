"use client";

import { ArrowRight, Check } from "lucide-react";
import { motion } from "motion/react";
import Link from "next/link";

import { Badge } from "@/components/shadcn/badge";
import { Button } from "@/components/shadcn/button";
import { facts, hero, moments } from "@/content/landing";

import { CheckinEditor } from "./checkin-editor";
import { EASE, Wrap } from "./primitives";

const rise = (i: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.8, ease: EASE, delay: 0.15 + i * 0.08 },
});

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="relative pt-[clamp(2.5rem,1.5rem+4vw,5.5rem)]">
      <Wrap className="grid items-center gap-x-14 gap-y-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.08fr)]">
        <div className="grid justify-items-start gap-[26px]">
          <motion.div {...rise(0)}>
            <Link href="#contacto" className="group inline-flex rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-ring">
              <Badge tone="brand" className="py-1.5 transition-colors group-hover:bg-brand-tint/70">
                {hero.badge}
                <ArrowRight className="size-3.5 transition-transform duration-300 group-hover:translate-x-0.5" aria-hidden />
              </Badge>
            </Link>
          </motion.div>

          <motion.h1 id="hero-title" {...rise(1)} className="max-w-[15ch] font-display text-[clamp(2.5rem,1.45rem+3.9vw,4.25rem)] leading-[1.02] tracking-[-0.035em] text-foreground">
            {hero.title.before} <span className="text-brand-display">{hero.title.accent}</span>
          </motion.h1>

          <motion.p {...rise(2)} className="max-w-[46ch] text-[1.125rem] leading-[1.62] text-muted-foreground">
            {hero.lead}
          </motion.p>

          <motion.div {...rise(3)} className="flex flex-wrap gap-2.5">
            <Button asChild size="lg">
              <Link href={hero.primary.href}>
                {hero.primary.label}
                <ArrowRight aria-hidden />
              </Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href={hero.secondary.href}>{hero.secondary.label}</Link>
            </Button>
          </motion.div>

          <motion.ul {...rise(4)} className="flex flex-wrap gap-x-5 gap-y-2 text-[0.9375rem] text-muted-foreground">
            {hero.trust.map((t) => (
              <li key={t} className="flex items-center gap-1.5">
                <Check className="size-4 text-brand-strong" aria-hidden />
                {t}
              </li>
            ))}
          </motion.ul>
        </div>

        <motion.div initial={{ opacity: 0, y: 28, scale: 0.985 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 1, ease: EASE, delay: 0.35 }}>
          <CheckinEditor />
        </motion.div>
      </Wrap>

      {/* Cuándo aparece el check-in: en pausas naturales, nunca en medio de una idea. */}
      <Wrap className="mt-[clamp(3rem,2rem+3vw,4.5rem)]">
        <p className="flex flex-wrap items-baseline gap-x-3 gap-y-1 border-t border-border pt-5 text-[0.9375rem] text-muted-foreground">
          <span className="font-medium text-foreground">Aparece en pausas naturales:</span>
          {moments.map((m, i) => (
            <span key={m} className="whitespace-nowrap">
              {m}
              {i < moments.length - 1 ? <span aria-hidden className="ml-3 text-border">/</span> : null}
            </span>
          ))}
        </p>
      </Wrap>

      {/* Cifras del producto: lo que Selyh promete por diseño (no son estadísticas de uso). */}
      <Wrap className="mt-[clamp(2.5rem,1.5rem+3vw,4.25rem)]">
        <dl className="grid grid-cols-2 gap-y-8 border-y border-border py-8 md:grid-cols-4 md:py-10">
          {facts.map((f, i) => (
            <div key={f.label} className={`flex flex-col-reverse justify-end gap-1.5 ${i % 2 === 1 ? "border-l border-border pl-6 md:pl-8" : i === 2 ? "md:border-l md:border-border md:pl-8" : ""}`}>
              <dt className="max-w-[22ch] text-[0.9375rem] leading-snug text-muted-foreground">{f.label}</dt>
              <dd className="flex items-baseline gap-2 font-display text-foreground">
                <span className="text-[clamp(2.25rem,1.6rem+2vw,3.25rem)] font-bold leading-none tracking-[-0.03em] tabular">{f.value}</span>
                <span className="text-[1.0625rem] font-semibold text-brand-strong">{f.unit}</span>
              </dd>
            </div>
          ))}
        </dl>
      </Wrap>
    </section>
  );
}

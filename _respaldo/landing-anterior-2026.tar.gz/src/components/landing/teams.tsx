"use client";

import { ArrowRight, Check } from "lucide-react";
import { motion } from "motion/react";
import Link from "next/link";

import { Button } from "@/components/shadcn/button";
import { teams } from "@/content/landing";

import { EASE, Eyebrow, Reveal, SectionTitle, Wrap } from "./primitives";

/* Carga media semanal del equipo (1–5), datos de ejemplo. Las semanas 6 y 7 coinciden con guardias. */
const WEEKS = [2.6, 2.8, 2.5, 2.9, 3.1, 3.7, 3.9, 3.2];
const MAX = 5;

/** Para equipos: tendencias agregadas, nunca personas. */
export function Teams() {
  return (
    <section id="equipos" aria-labelledby="equipos-title" className="scroll-mt-24 py-[clamp(4.5rem,3rem+5vw,7rem)]">
      <Wrap className="grid gap-14 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:items-center lg:gap-[68px]">
        <Reveal className="grid content-start gap-[26px]">
          <Eyebrow n="05">{teams.eyebrow}</Eyebrow>
          <SectionTitle id="equipos-title">{teams.title}</SectionTitle>
          <p className="max-w-[56ch] text-[1.0625rem] leading-[1.65] text-muted-foreground">{teams.body}</p>
          <ul className="grid gap-3">
            {teams.points.map((p) => (
              <li key={p} className="flex items-start gap-3 text-[0.9375rem]">
                <Check className="mt-0.5 size-[18px] shrink-0 text-brand-strong" aria-hidden />
                {p}
              </li>
            ))}
          </ul>
          <Button asChild size="lg" variant="outline" className="w-fit">
            <Link href={teams.cta.href}>
              {teams.cta.label}
              <ArrowRight aria-hidden />
            </Link>
          </Button>
        </Reveal>

        <Reveal delay={0.1}>
          <figure className="rounded-2xl border border-border bg-background p-[26px] shadow-[0_30px_60px_-40px_rgb(15_21_35/0.4)]">
            <figcaption className="flex flex-wrap items-baseline justify-between gap-2">
              <span className="font-display text-lg font-semibold">{teams.chart.title}</span>
              <span className="text-[0.8125rem] text-muted-foreground">{teams.chart.note}</span>
            </figcaption>

            <div className="relative mt-6 h-52" role="img" aria-label="Barras de ejemplo: la carga media del equipo sube en las semanas 6 y 7 y vuelve a bajar en la 8.">
              <div aria-hidden className="relative flex h-full items-end gap-2 sm:gap-3">
                {WEEKS.map((v, i) => (
                  <div key={i} className="flex h-full flex-1 flex-col justify-end">
                    <motion.div
                      initial={{ scaleY: 0 }}
                      whileInView={{ scaleY: 1 }}
                      viewport={{ once: true, amount: 0.6 }}
                      transition={{ duration: 0.8, ease: EASE, delay: 0.1 + i * 0.06 }}
                      style={{ height: `${(v / MAX) * 100}%` }}
                      className={`origin-bottom rounded-t-[10px] rounded-b-[4px] ${v > 3.2 ? "bg-primary" : "bg-brand-soft"}`}
                    />
                  </div>
                ))}
              </div>
              <div
                aria-hidden
                className="pointer-events-none absolute -inset-x-2 border-y border-dashed border-brand-strong/50 bg-brand-strong/[0.07]"
                style={{ bottom: `${(2.3 / MAX) * 100}%`, height: `${(0.9 / MAX) * 100}%` }}
              />
            </div>
            <div aria-hidden className="mt-2 flex gap-2 text-center text-[0.75rem] text-muted-foreground tabular sm:gap-3">
              {WEEKS.map((_, i) => (
                <span key={i} className="flex-1">
                  S{i + 1}
                </span>
              ))}
            </div>

            <div className="mt-5 flex flex-wrap items-center gap-x-5 gap-y-2 border-t border-border pt-4 text-[0.8125rem] text-muted-foreground">
              <span className="flex items-center gap-2">
                <span aria-hidden className="h-2.5 w-4 border-y border-dashed border-brand-strong/60 bg-brand-strong/10" />
                Rango habitual del equipo
              </span>
              <span className="flex items-center gap-2">
                <span aria-hidden className="size-2.5 rounded-sm bg-primary" />
                Por encima del rango
              </span>
            </div>
            <p className="mt-4 rounded-xl bg-surface-raised px-4 py-3 text-[0.875rem] text-muted-foreground">{teams.chart.threshold}</p>
          </figure>
        </Reveal>
      </Wrap>
    </section>
  );
}

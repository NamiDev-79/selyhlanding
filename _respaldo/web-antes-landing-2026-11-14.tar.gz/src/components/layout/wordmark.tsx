import Link from "next/link";

/** Logotipo tipográfico: "selyh" en la display, con un punto de respiración en degradado. */
export function Wordmark({ href = "/", className = "" }: { href?: string; className?: string }) {
  return (
    <Link href={href} className={`group inline-flex items-center gap-1 font-display text-[1.45rem] font-bold leading-none tracking-[-0.04em] text-ink ${className}`} aria-label="Selyh, inicio">
      <span>selyh</span>
      <span
        aria-hidden
        className="inline-block size-[0.34em] translate-y-[0.2em] rounded-full bg-gradient-to-br from-accent to-mint transition-transform duration-500 group-hover:scale-125"
      />
    </Link>
  );
}

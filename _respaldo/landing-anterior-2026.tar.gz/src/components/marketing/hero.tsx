import { LinkButton } from "@/components/ui/button";
import { Icon } from "@/components/ui/icons";
import { hero, moments } from "@/content/landing";

import { CheckinDemo } from "./checkin-demo";

const chips = [
  { text: "Línea base calibrada", icon: "check", className: "-top-5 left-8 text-mint-ink", i: 0 },
  { text: "Pausa sugerida · 2 min", icon: "clock", className: "-top-5 right-8 text-warm-ink", i: 1 },
  { text: "Solo números, nunca código", icon: "eyeOff", className: "-bottom-5 right-[22%] text-accent-strong", i: 2 },
] as const;

/** Fondo de la portada: manchas de color que se desplazan lento sobre una rejilla de puntos. */
function Aurora() {
  return (
    <div aria-hidden className="pointer-events-none absolute inset-0 -z-10 overflow-hidden">
      <div className="dots absolute inset-0 [mask-image:radial-gradient(ellipse_70%_60%_at_50%_30%,black,transparent)]" />
      <div className="drift absolute -top-40 left-[8%] size-[34rem] rounded-full bg-[oklch(80%_0.12_277/0.55)] blur-3xl" />
      <div className="drift absolute -top-20 right-[4%] size-[28rem] rounded-full bg-[oklch(88%_0.11_168/0.6)] blur-3xl" style={{ "--i": 1 } as React.CSSProperties} />
      <div className="drift absolute top-[30%] left-[38%] size-[22rem] rounded-full bg-[oklch(90%_0.1_75/0.5)] blur-3xl" style={{ "--i": 2 } as React.CSSProperties} />
      <div className="absolute inset-x-0 bottom-0 h-56 bg-gradient-to-b from-transparent to-paper" />
    </div>
  );
}

export function Hero() {
  return (
    <section aria-labelledby="hero-title" className="relative isolate overflow-hidden pt-[clamp(3rem,2rem+5vw,6.5rem)]">
      <Aurora />
      <div className="wrap grid justify-items-center gap-7 text-center">
        <a href="#contacto" className="rise kicker transition-colors hover:text-ink">
          {hero.badge}
          <Icon name="arrow" className="size-3.5" />
        </a>
        <h1 id="hero-title" className="rise max-w-[16ch] text-step-5" style={{ "--i": 1 } as React.CSSProperties}>
          {hero.title.before} <span className="ink-gradient">{hero.title.accent}</span>
        </h1>
        <p className="rise max-w-[54ch] text-step-1 leading-relaxed text-ink-soft" style={{ "--i": 2 } as React.CSSProperties}>
          {hero.lead}
        </p>
        <div className="rise flex flex-wrap justify-center gap-3" style={{ "--i": 3 } as React.CSSProperties}>
          <LinkButton href={hero.primary.href} size="lg">
            {hero.primary.label}
            <Icon name="arrow" className="size-4" />
          </LinkButton>
          <LinkButton href={hero.secondary.href} variant="secondary" size="lg">
            {hero.secondary.label}
          </LinkButton>
        </div>
        <ul className="rise flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-ink-soft" style={{ "--i": 4 } as React.CSSProperties}>
          {hero.trust.map((t) => (
            <li key={t} className="flex items-center gap-1.5">
              <Icon name="check" className="size-4 text-mint-ink" />
              {t}
            </li>
          ))}
        </ul>
      </div>

      <div className="wrap relative mt-14 max-w-[64rem] lg:mt-16">
        <div className="rise relative z-0" style={{ "--i": 5 } as React.CSSProperties}>
          <CheckinDemo />
        </div>
        {chips.map((c) => (
          <span
            key={c.text}
            aria-hidden
            className={`float absolute z-10 hidden items-center gap-2 rounded-full border border-line bg-paper/90 px-3.5 py-2 text-sm font-medium shadow-float backdrop-blur xl:inline-flex ${c.className}`}
            style={{ "--i": c.i } as React.CSSProperties}
          >
            <Icon name={c.icon} className="size-4" />
            <span className="text-ink">{c.text}</span>
          </span>
        ))}
      </div>

      {/* Cinta de momentos: cuándo aparece el check-in. */}
      <div className="mt-16 border-y border-line bg-paper-2/70 py-4 [mask-image:linear-gradient(90deg,transparent,black_12%,black_88%,transparent)]">
        <p className="sr-only">El check-in aparece en pausas naturales: {moments.join(", ")}.</p>
        <div aria-hidden className="marquee flex w-max gap-10">
          {[...moments, ...moments].map((m, i) => (
            <span key={i} className="flex items-center gap-10 whitespace-nowrap font-display text-step-1 font-medium text-ink-faint">
              {m}
              <span className="size-1.5 rounded-full bg-accent/50" />
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}

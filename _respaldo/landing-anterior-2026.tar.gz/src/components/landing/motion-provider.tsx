"use client";

import { MotionConfig } from "motion/react";
import type { ReactNode } from "react";

/** Respeta "reducir movimiento" del sistema: las animaciones de Motion se vuelven instantáneas. */
export function MotionProvider({ children }: { children: ReactNode }) {
  return <MotionConfig reducedMotion="user">{children}</MotionConfig>;
}

import { Icon, type IconName } from "@/components/ui/icons";
import { where } from "@/content/landing";

import { SectionHead } from "./section-head";

/** Muestra fiel de cómo se ve el check-in en la barra de estado del editor. */
function StatusBarGlimpse() {
  const s = where.statusBar;
  return (
    <div className="overflow-hidden rounded-xl border border-white/10 bg-night font-mono text-[12px] text-white/80" aria-label="Así se ve el check-in en la barra de estado de VS Code" role="img">
      <div className="grid gap-1 px-4 py-4 leading-relaxed">
        <p>
          <span className="text-white/30">41</span>  <span className="text-[oklch(78%_0.13_300)]">export async function</span> conciliar(lote) {"{"}
        </p>
        <p>
          <span className="text-white/30">42</span>    <span className="text-white/45">{"// ✓ commit: fix redondeo"}</span>
        </p>
        <p>
          <span className="text-white/30">43</span>  {"}"}
        </p>
      </div>
      <div className="flex flex-wrap items-center gap-x-3 gap-y-2 bg-accent-strong px-3 py-1.5 text-white">
        <span className="flex items-center gap-1.5">
          <span aria-hidden className="breathe size-2 rounded-full bg-mint" />
          {s.brand}
        </span>
        <span>{s.question}</span>
        <span className="flex gap-1">
          {[1, 2, 3, 4, 5].map((n) => (
            <span key={n} className={`grid size-5 place-items-center rounded-sm ${n === 3 ? "bg-white text-accent-strong" : "border border-white/40"}`}>
              {n}
            </span>
          ))}
        </span>
      </div>
    </div>
  );
}

function DesktopToast() {
  const n = where.notification;
  return (
    <div className="float ml-auto w-full max-w-[17rem] rounded-xl border border-line bg-paper p-3 shadow-float" aria-hidden>
      <div className="flex items-center gap-2 text-xs font-semibold">
        <span className="grid size-5 place-items-center rounded-md bg-accent text-[10px] text-white">S</span>
        {n.title}
        <span className="ml-auto font-normal text-ink-faint">ahora</span>
      </div>
      <p className="mt-1.5 text-sm text-ink-soft">{n.body}</p>
    </div>
  );
}

function PhoneGlimpse() {
  return (
    <div aria-hidden className="mx-auto h-36 w-24 rounded-[1.1rem] border-4 border-ink/85 bg-paper p-2 shadow-card">
      <div className="mx-auto mb-2 h-1 w-6 rounded-full bg-ink/20" />
      <p className="text-[8px] font-semibold">WHO-5</p>
      <div className="mt-1.5 grid gap-1">
        {[70, 55, 85, 40].map((w) => (
          <div key={w} className="h-1.5 rounded-full bg-paper-3">
            <div className="h-full rounded-full bg-mint" style={{ width: `${w}%` }} />
          </div>
        ))}
      </div>
    </div>
  );
}

function PanelGlimpse() {
  return (
    <div aria-hidden className="grid grid-cols-[2.2rem_1fr] overflow-hidden rounded-xl border border-line bg-paper shadow-card">
      <div className="grid content-start gap-1.5 border-r border-line bg-paper-2 p-2">
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={`h-1.5 rounded-full ${i === 0 ? "bg-accent" : "bg-line-strong"}`} />
        ))}
      </div>
      <div className="grid gap-2 p-3">
        <span className="h-2 w-1/2 rounded-full bg-ink/80" />
        <div className="flex h-12 items-end gap-1">
          {[30, 45, 35, 60, 50, 75, 55, 40].map((h, i) => (
            <span key={i} className="flex-1 rounded-t-sm bg-accent/70" style={{ height: `${h}%` }} />
          ))}
        </div>
      </div>
    </div>
  );
}

const visuals: { icon: IconName; visual: React.ReactNode; className: string }[] = [
  { icon: "code", visual: <StatusBarGlimpse />, className: "md:col-span-2 lg:col-span-4" },
  { icon: "monitor", visual: <DesktopToast />, className: "lg:col-span-2" },
  { icon: "phone", visual: <PhoneGlimpse />, className: "lg:col-span-2" },
  { icon: "layout", visual: <PanelGlimpse />, className: "md:col-span-2 lg:col-span-4" },
];

export function Where() {
  return (
    <section aria-labelledby="donde" className="wrap py-[var(--section)]">
      <SectionHead id="donde" eyebrow={where.eyebrow} title={where.title} center />
      <div className="mt-14 grid gap-5 md:grid-cols-2 lg:grid-cols-6">
        {where.places.map((p, i) => {
          const v = visuals[i]!;
          const wide = i === 3;
          return (
            <article key={p.name} className={`reveal ${v.className}`}>
              <div className={`card grid h-full gap-6 overflow-hidden p-6 ${wide || i === 0 ? "lg:grid-cols-[1fr_1.3fr] lg:items-center" : ""} ${i === 0 ? "bg-gradient-to-br from-accent-wash to-paper" : ""}`}>
                <div className="grid content-start gap-2">
                  <span className="grid size-10 place-items-center rounded-xl bg-paper-2 text-accent-strong ring-1 ring-line">
                    <Icon name={v.icon} />
                  </span>
                  <h3 className="mt-2 text-step-1">{p.name}</h3>
                  <p className="max-w-[46ch] text-[0.95rem] text-ink-soft">{p.body}</p>
                </div>
                <div>{v.visual}</div>
              </div>
            </article>
          );
        })}
      </div>
      <p className="reveal mt-6 text-center text-step--1 text-ink-faint">{where.statusBar.hint}. Aparece después de un commit, nunca a mitad de una idea.</p>
    </section>
  );
}

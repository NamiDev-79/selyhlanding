"use client";

import { Check } from "lucide-react";
import { motion } from "motion/react";
import Link from "next/link";

import { Badge } from "@/components/shadcn/badge";
import { Button } from "@/components/shadcn/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/shadcn/card";
import { plans, plansIntro } from "@/content/plans";
import { cn } from "@/lib/utils";

import { EASE, Eyebrow, Reveal, SectionTitle, Wrap } from "./primitives";

/** Planes: lo esencial es gratis. El plan destacado lleva el único botón primario de la sección. */
export function Plans() {
  return (
    <section id="planes" aria-labelledby="planes-title" className="scroll-mt-24 bg-surface-raised py-[clamp(4.5rem,3rem+5vw,7rem)]">
      <Wrap>
        <Reveal className="grid gap-[26px] lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)] lg:items-end lg:gap-[68px]">
          <div className="grid gap-[26px]">
            <Eyebrow n="07">{plansIntro.eyebrow}</Eyebrow>
            <SectionTitle id="planes-title">{plansIntro.title}</SectionTitle>
          </div>
          <p className="max-w-[52ch] text-[1.0625rem] leading-[1.65] text-muted-foreground">{plansIntro.body}</p>
        </Reveal>

        <div className="mt-12 grid gap-4 lg:grid-cols-3">
          {plans.map((p, i) => (
            <motion.div
              key={p.id}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.3 }}
              transition={{ duration: 0.65, ease: EASE, delay: i * 0.08 }}
              className="flex"
            >
              <Card className={cn("w-full", p.featured && "border-primary shadow-[0_0_0_1px_var(--primary),0_30px_60px_-36px_rgb(99_99_241/0.55)]")}>
                <CardHeader>
                  <div className="flex items-center justify-between gap-3">
                    <CardTitle>{p.name}</CardTitle>
                    {p.featured ? <Badge tone="brand">Más completo</Badge> : null}
                  </div>
                  <CardDescription className="lg:min-h-[2.9rem]">{p.audience}</CardDescription>
                </CardHeader>
                <p className="flex items-baseline gap-2">
                  <span className="font-display text-[2.625rem] font-bold leading-none tracking-[-0.03em] tabular">
                    <span className="mr-0.5 align-top text-[1.25rem] font-semibold">$</span>
                    {p.price}
                  </span>
                  <span className="text-[0.875rem] text-muted-foreground">{p.unit}</span>
                </p>
                <CardContent>
                  <ul className="grid gap-2.5 border-t border-border pt-5">
                    {p.highlights.map((h) => (
                      <li key={h} className="flex items-start gap-2.5 text-[0.9375rem]">
                        <Check className="mt-0.5 size-4 shrink-0 text-brand-strong" aria-hidden />
                        {h}
                      </li>
                    ))}
                  </ul>
                </CardContent>
                <CardFooter className="pt-2">
                  <Button asChild size="lg" variant={p.featured ? "default" : "outline"} className="w-full">
                    <Link href={p.cta.href}>{p.cta.label}</Link>
                  </Button>
                </CardFooter>
              </Card>
            </motion.div>
          ))}
        </div>

        <p className="mt-6 max-w-[70ch] text-[0.875rem] text-muted-foreground">{plansIntro.referential}</p>
      </Wrap>
    </section>
  );
}

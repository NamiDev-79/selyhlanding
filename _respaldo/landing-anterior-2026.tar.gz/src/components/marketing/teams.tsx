import { LinkButton } from "@/components/ui/button";
import { Icon } from "@/components/ui/icons";
import { teams } from "@/content/landing";
import { sampleTeam, sampleTeamEvents } from "@/content/sample-data";

import { SectionHead } from "./section-head";

/** Columnas semanales de un agregado de equipo, con eventos organizacionales anotados. */
function TeamChart() {
  const max = 1;
  return (
    <figure className="card relative grid gap-5 p-6 sm:p-7">
      <figcaption className="flex items-center justify-between gap-4">
        <span className="flex items-center gap-2 font-semibold">
          <span className="grid size-8 place-items-center rounded-lg bg-accent-wash text-accent-strong">
            <Icon name="users" className="size-4" />
          </span>
          {teams.chart.title}
        </span>
        <span className="eyebrow">{teams.chart.note}</span>
      </figcaption>
      <div className="relative mt-8 grid h-52 grid-cols-12 items-end gap-1.5" role="img" aria-label="Ejemplo: la carga media del equipo sube durante la rotación de guardias y baja cuando se reparte la guardia.">
        {sampleTeam.map((v, i) => {
          const event = sampleTeamEvents.find((e) => e.at === i);
          const high = v >= 0.5;
          return (
            <div key={i} className="relative flex h-full flex-col justify-end">
              {event ? (
                <span className="absolute -top-2 left-0 z-10 w-max max-w-[9rem] -translate-y-full rounded-md bg-ink px-2 py-1 text-[11px] font-medium leading-tight text-paper">{event.label}</span>
              ) : null}
              <div
                className="rounded-t-md"
                style={{
                  height: `${Math.max(6, ((v + 0.2) / (max + 0.2)) * 100)}%`,
                  background: high
                    ? "linear-gradient(180deg, var(--warm), color-mix(in oklch, var(--warm) 55%, transparent))"
                    : "linear-gradient(180deg, var(--accent), color-mix(in oklch, var(--accent) 35%, transparent))",
                }}
              />
            </div>
          );
        })}
      </div>
      <div className="flex justify-between font-mono text-[11px] text-ink-faint">
        <span>semana 1</span>
        <span>semana 12</span>
      </div>
      <p className="flex items-start gap-2 rounded-xl bg-paper-2 p-3 text-step--1 text-ink-soft">
        <Icon name="shield" className="mt-0.5 size-4 shrink-0 text-accent-strong" />
        {teams.chart.threshold}
      </p>
    </figure>
  );
}

export function Teams() {
  return (
    <section id="equipos" aria-labelledby="equipos-title" className="wrap grid scroll-mt-24 gap-14 py-[var(--section)] lg:grid-cols-[1fr_1.1fr] lg:items-center lg:gap-20">
      <div className="grid content-start gap-8">
        <SectionHead id="equipos-title" eyebrow={teams.eyebrow} title={teams.title}>
          <p className="max-w-[50ch] text-ink-soft">{teams.body}</p>
        </SectionHead>
        <ul className="reveal grid gap-3">
          {teams.points.map((p) => (
            <li key={p} className="flex items-start gap-3">
              <span className="mt-0.5 grid size-6 shrink-0 place-items-center rounded-full bg-mint-wash text-mint-ink">
                <Icon name="check" className="size-3.5" />
              </span>
              <span>{p}</span>
            </li>
          ))}
        </ul>
        <div className="reveal flex flex-wrap gap-3">
          <LinkButton href={teams.cta.href} variant="dark">
            {teams.cta.label}
            <Icon name="arrow" className="size-4" />
          </LinkButton>
          <LinkButton href="/registro?tipo=corporativa" variant="secondary">
            Crear cuenta corporativa
          </LinkButton>
        </div>
      </div>
      <div className="reveal">
        <TeamChart />
      </div>
    </section>
  );
}

"use client";

import { PageHeader } from "@/components/layout/app-shell";
import { MembersManager } from "@/features/company/management";

export default function MembersPage() {
  return (
    <>
      <PageHeader title="Miembros e invitaciones" />
      <MembersManager />
    </>
  );
}

/**
 * Texto de las escalas que ve la persona.
 *
 * ⚠️ LICENCIAS: el texto oficial de los ítems NO se incluye en el repositorio hasta revisar las
 * condiciones de uso (PSS-10: Cohen; PHQ-9/GAD-7: Pfizer; WHO-5: OMS). Para habilitar una escala,
 * pega en `items` la versión validada en español, en orden (índice 0 = ítem 1), sin parafrasear:
 * cambiar las palabras invalida el instrumento. Mientras `items` esté vacío se muestra "Pregunta N".
 */
export type ScaleText = {
  about: string;
  period: string;
  options: string[]; // una etiqueta por valor, desde el mínimo
  items: string[];
};

export const scaleText: Record<string, ScaleText> = {
  PSS10: {
    about: "Cuánto estrés has percibido. Diez preguntas.",
    period: "Durante el último mes, ¿con qué frecuencia…",
    options: ["Nunca", "Casi nunca", "A veces", "Bastante a menudo", "Muy a menudo"],
    items: [],
  },
  WHO5: {
    about: "Tu bienestar general. Cinco preguntas de la OMS.",
    period: "Durante las últimas dos semanas…",
    options: ["Nunca", "De vez en cuando", "Menos de la mitad del tiempo", "Más de la mitad del tiempo", "La mayor parte del tiempo", "Todo el tiempo"],
    items: [],
  },
  PHQ9: {
    about: "Tamizaje de ánimo. Nueve preguntas. Orienta, no diagnostica.",
    period: "Durante las últimas dos semanas, ¿con qué frecuencia te han molestado…",
    options: ["Ningún día", "Varios días", "Más de la mitad de los días", "Casi todos los días"],
    items: [],
  },
  GAD7: {
    about: "Tamizaje de ansiedad. Siete preguntas. Orienta, no diagnostica.",
    period: "Durante las últimas dos semanas, ¿con qué frecuencia te han molestado…",
    options: ["Ningún día", "Varios días", "Más de la mitad de los días", "Casi todos los días"],
    items: [],
  },
};

export const scalesCopy = {
  title: "Escalas",
  lead: "Cuestionarios validados que respondes por partes, tres preguntas a la vez. Son la referencia con la que medimos si algo cambia.",
  start: "Empezar",
  resume: "Continuar",
  restart: "Empezar de nuevo",
  save: "Guardar estas respuestas",
  finish: "Ver resultado",
  done: "Listo por hoy. Puedes seguir más tarde: guardamos tu avance.",
  last: "Última vez",
  never: "Aún no la respondes",
  pendingText: "Texto del ítem pendiente de licencia",
  resultNote: "Es una referencia, no un diagnóstico.",
};

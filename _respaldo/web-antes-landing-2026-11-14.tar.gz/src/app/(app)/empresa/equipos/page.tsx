"use client";

import { PageHeader } from "@/components/layout/app-shell";
import { TeamsManager } from "@/features/company/management";

export default function TeamsPage() {
  return (
    <>
      <PageHeader title="Equipos" />
      <TeamsManager />
    </>
  );
}

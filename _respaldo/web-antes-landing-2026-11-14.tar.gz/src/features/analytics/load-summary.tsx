"use client";

import { Loading, Notice } from "@/components/ui/feedback";
import { TrendChart } from "@/components/ui/trend-chart";
import { loadCopy } from "@/content/panel";
import { errorText } from "@/lib/api/client";
import { useAnalytics } from "@/features/checkins/hooks";

/** Rellena los días sin estimado con null para que la línea se corte en vez de inventar valores. */
function fillDays(series: { date: string; zScoreAvg: number }[], days: number): (number | null)[] {
  if (!series.length) return [];
  const byDate = new Map(series.map((s) => [s.date, s.zScoreAvg]));
  const end = new Date(`${series[series.length - 1]!.date}T00:00:00Z`);
  const out: (number | null)[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date(end.getTime() - i * 86_400_000).toISOString().slice(0, 10);
    out.push(byDate.get(d) ?? null);
  }
  return out;
}

/** Calibración o estimado de carga + tendencia, con el aviso de que no es un diagnóstico. */
export function LoadSummary({ days = 30, compact = false }: { days?: number; compact?: boolean }) {
  const q = useAnalytics(days);
  const c = loadCopy;
  if (q.isPending) return <Loading />;
  if (q.isError) return <Notice tone="attention" title={errorText(q.error)} />;

  const { calibration, latest, series, disclaimer } = q.data;

  if (!calibration.calibrated) {
    const pct = Math.min(100, Math.round((calibration.daysWithData / calibration.required) * 100));
    return (
      <section aria-labelledby="carga" className="grid gap-4">
        <div className="flex items-baseline justify-between gap-4">
          <h2 id="carga" className="text-step-2">
            {c.title}
          </h2>
          <span className="eyebrow">{c.calibrating}</span>
        </div>
        <div className="grid gap-2">
          <div className="h-1.5 overflow-hidden rounded-full bg-paper-3" role="progressbar" aria-valuemin={0} aria-valuemax={calibration.required} aria-valuenow={calibration.daysWithData} aria-label="Días de calibración">
            <div className="h-full rounded-full bg-accent transition-[width] duration-700" style={{ width: `${pct}%` }} />
          </div>
          <p className="figures text-sm text-ink-faint">
            {calibration.daysWithData} / {calibration.required} días
          </p>
        </div>
        <p className="max-w-[52ch] text-ink-soft">{c.calibratingBody(calibration.daysWithData, calibration.required)}</p>
      </section>
    );
  }

  return (
    <section aria-labelledby="carga" className="grid gap-4">
      <div className="flex flex-wrap items-baseline justify-between gap-4">
        <h2 id="carga" className="text-step-2">
          {c.title}
        </h2>
        {latest ? (
          <span className="flex items-center gap-2 text-sm">
            <span aria-hidden className={`size-2 rounded-full ${latest.trendLabel === "STABLE" ? "bg-accent" : "bg-warm"}`} />
            {c.trend[latest.trendLabel]}
          </span>
        ) : null}
      </div>
      {latest ? <p className="max-w-[40ch] font-display text-step-2 leading-snug">{latest.message}.</p> : <p className="text-ink-soft">{c.noToday}</p>}
      {series.length > 1 ? (
        <TrendChart
          values={fillDays(series, Math.min(days, 30))}
          bandLabel="tu rango habitual"
          labels={[`hace ${Math.min(days, 30)} días`, "hoy"]}
          ariaLabel={`Tendencia de tu carga en los últimos ${Math.min(days, 30)} días respecto a tu línea base.`}
          height={compact ? 180 : 240}
        />
      ) : null}
      {latest ? (
        <p className="figures text-xs text-ink-faint">
          {c.confidence}: {Math.round(latest.confidenceLevel * 100)}% · z {latest.zScoreAvg.toFixed(2)}
        </p>
      ) : null}
      <p className="text-step--1 text-ink-faint">{disclaimer}</p>
    </section>
  );
}

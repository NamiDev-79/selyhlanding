"use client";

import { motion } from "motion/react";

import { problem } from "@/content/landing";

import { EASE, Eyebrow, Reveal, SectionTitle, Wrap } from "./primitives";

/** El problema: el cansancio se acumula sin avisar. A la derecha, un martes cualquiera sin una sola pausa. */
export function Problem() {
  return (
    <section aria-labelledby="problema-title" className="py-[clamp(4.5rem,3rem+5vw,7rem)]">
      <Wrap className="grid gap-12 lg:grid-cols-[minmax(0,1.618fr)_minmax(0,1fr)] lg:gap-[68px]">
        <Reveal className="grid content-start gap-[26px]">
          <Eyebrow n="01">{problem.eyebrow}</Eyebrow>
          <SectionTitle id="problema-title">{problem.title}</SectionTitle>
          <div className="grid max-w-[60ch] gap-4 text-[1.0625rem] leading-[1.65] text-muted-foreground">
            {problem.body.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>
        </Reveal>

        <Reveal delay={0.1} className="self-end">
          <figure className="rounded-2xl border border-border bg-surface-raised p-[26px]">
            <figcaption className="text-[0.8125rem] font-medium uppercase tracking-[0.08em] text-muted-foreground">{problem.day.label}</figcaption>
            <ol className="relative mt-5 grid gap-3.5 before:absolute before:bottom-2 before:left-[3.225rem] before:top-2 before:w-px before:bg-border">
              {problem.day.events.map((e, i) => (
                <motion.li
                  key={e.time}
                  initial={{ opacity: 0, x: -8 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, amount: 0.8 }}
                  transition={{ duration: 0.5, ease: EASE, delay: 0.15 + i * 0.07 }}
                  className="relative grid grid-cols-[2.6rem_1fr] items-center gap-5 text-[0.9375rem]"
                >
                  <time className="text-right text-muted-foreground tabular">{e.time}</time>
                  <span className="relative text-foreground before:absolute before:-left-[calc(0.625rem+3.5px)] before:top-1/2 before:size-[7px] before:-translate-y-1/2 before:rounded-full before:bg-foreground/35">
                    {e.text}
                  </span>
                </motion.li>
              ))}
            </ol>
            <p className="mt-6 flex items-baseline justify-between border-t border-border pt-4">
              <span className="text-[0.9375rem] text-muted-foreground">Pausas reales</span>
              <span className="font-display text-[2.625rem] font-bold leading-none tracking-[-0.03em] text-foreground tabular">0</span>
            </p>
          </figure>
        </Reveal>
      </Wrap>
    </section>
  );
}

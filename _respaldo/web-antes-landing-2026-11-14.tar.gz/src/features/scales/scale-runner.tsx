"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

import { Button } from "@/components/ui/button";
import { Loading, Notice } from "@/components/ui/feedback";
import { scalesCopy, scaleText } from "@/content/scales";
import { errorText, type Res } from "@/lib/api/client";
import { CrisisResources } from "@/features/crisis/crisis-resources";

import { type ScaleCode, useCompleteScale, useResetScale, useSaveAnswers, useScaleCatalog, useScaleHistory, useScaleProgress } from "./hooks";

type Catalog = Res<"/scales", "get">[number];
type Progress = Res<"/scales/progress", "get">[number];
type Result = Res<"/scales/{code}/progress/complete", "post">;
type Resources = NonNullable<Res<"/scales/{code}/progress", "put">["crisis"]>["resources"];

const c = scalesCopy;
const BATCH = 3;

/** Primera tanda cuando aún no hay avance guardado. En PHQ-9 el ítem 9 va primero (protocolo de crisis). */
function firstItems(code: string, total: number) {
  const order = code === "PHQ9" ? [8, ...Array.from({ length: total - 1 }, (_, i) => i)] : Array.from({ length: total }, (_, i) => i);
  return order.slice(0, BATCH);
}

const fmtDate = (iso: string) => new Date(iso).toLocaleDateString("es-PE", { day: "numeric", month: "short", year: "numeric" });

/** Lista de escalas con su estado y el cuestionario por partes de la elegida (?code=…). */
export function ScalesView() {
  const params = useSearchParams();
  const router = useRouter();
  const code = params.get("code");
  const catalog = useScaleCatalog();
  const progress = useScaleProgress();
  const history = useScaleHistory();

  if (catalog.isPending || progress.isPending) return <Loading />;
  if (catalog.isError) return <Notice tone="attention" title={errorText(catalog.error)} />;

  const selected = catalog.data.find((s) => s.code === code);
  if (selected) {
    return <Runner key={selected.code} scale={selected as Catalog & { code: ScaleCode }} progress={progress.data?.find((p) => p.code === selected.code)} onClose={() => router.push("/panel/escalas")} />;
  }

  return (
    <ul className="grid border-t border-ink">
      {catalog.data.map((s) => {
        const p = progress.data?.find((x) => x.code === s.code);
        const last = history.data?.find((h) => h.instrument === s.code);
        return (
          <li key={s.code} className="grid gap-3 border-b border-line py-6 sm:grid-cols-[1fr_auto] sm:items-center sm:gap-10">
            <div className="grid gap-1">
              <h2 className="text-step-2">{s.name}</h2>
              <p className="text-ink-soft">{scaleText[s.code]?.about}</p>
              <p className="figures text-xs text-ink-faint">
                {p ? `En curso: ${p.answered} de ${p.total}` : last ? `${c.last}: ${fmtDate(last.completedAt)} · ${last.totalScore}/${s.maxScore}` : c.never}
              </p>
            </div>
            <Button variant={p ? "primary" : "secondary"} onClick={() => router.push(`/panel/escalas?code=${s.code}`)}>
              {p ? c.resume : c.start}
            </Button>
          </li>
        );
      })}
    </ul>
  );
}

function Runner({ scale, progress, onClose }: { scale: Catalog & { code: ScaleCode }; progress?: Progress; onClose: () => void }) {
  const text = scaleText[scale.code];
  const save = useSaveAnswers(scale.code);
  const complete = useCompleteScale(scale.code);
  const reset = useResetScale(scale.code);
  const [state, setState] = useState(() => ({
    answered: progress?.answered ?? 0,
    nextItems: progress?.nextItems?.length ? progress.nextItems : firstItems(scale.code, scale.items),
  }));
  const [draft, setDraft] = useState<Record<number, number>>({});
  const [crisis, setCrisis] = useState<Resources | null>(null);
  const [result, setResult] = useState<Result | null>(null);

  const options = Array.from({ length: scale.maxPerItem - scale.minPerItem + 1 }, (_, i) => scale.minPerItem + i);
  const complete_ = state.answered >= scale.items;
  const ready = state.nextItems.every((i) => draft[i] !== undefined);

  const submit = () =>
    save.mutate(
      state.nextItems.map((index) => ({ index, value: draft[index]! })),
      {
        onSuccess: (r) => {
          setState({ answered: r.answered, nextItems: r.nextItems });
          setDraft({});
          if (r.crisis) setCrisis(r.crisis.resources);
        },
      },
    );

  if (result) {
    return (
      <div className="grid gap-8">
        {result.crisis ? <CrisisResources resources={result.crisis.resources} /> : null}
        <article className="grid gap-4 border-t border-ink pt-6">
          <p className="eyebrow">{scale.name}</p>
          <p className="flex items-baseline gap-3">
            <span className="font-display text-step-5 leading-none">{result.totalScore}</span>
            <span className="figures text-ink-faint">/ {result.maxScore}</span>
          </p>
          <p className="text-step-1 first-letter:uppercase">{result.band}</p>
          <p className="max-w-[56ch] text-ink-soft">{result.note}</p>
          <p className="text-step--1 text-ink-faint">{c.resultNote}</p>
        </article>
        <div>
          <Button variant="secondary" onClick={onClose}>
            Volver a las escalas
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-8">
      {/* Con riesgo detectado, la ayuda va primero: antes de seguir con cualquier pregunta. */}
      {crisis ? <CrisisResources resources={crisis} /> : null}

      <header className="grid gap-3">
        <div className="flex items-baseline justify-between gap-4">
          <h2 className="text-step-3">{scale.name}</h2>
          <span className="figures text-sm text-ink-faint">
            {state.answered} / {scale.items}
          </span>
        </div>
        <div className="h-1 overflow-hidden rounded-full bg-paper-3" aria-hidden>
          <div className="h-full bg-accent transition-[width] duration-500" style={{ width: `${(state.answered / scale.items) * 100}%` }} />
        </div>
        {text ? <p className="text-ink-soft">{text.period}</p> : null}
      </header>

      {complete_ ? (
        <div className="grid gap-4">
          <p>Respondiste todas las preguntas.</p>
          <div>
            <Button pending={complete.isPending} onClick={() => complete.mutate(undefined, { onSuccess: setResult })}>
              {c.finish}
            </Button>
          </div>
          {complete.isError ? <Notice tone="attention" title={errorText(complete.error)} /> : null}
        </div>
      ) : (
        <form
          className="grid gap-8"
          onSubmit={(e) => {
            e.preventDefault();
            if (ready) submit();
          }}
        >
          {state.nextItems.map((index) => (
            <fieldset key={index} className="grid gap-3 border-t border-line pt-5">
              <legend className="mb-3 grid gap-1">
                <span className="figures text-xs text-ink-faint">Pregunta {index + 1}</span>
                <span className="text-step-1">{text?.items[index] ?? `Pregunta ${index + 1}`}</span>
                {!text?.items[index] ? <span className="text-step--1 text-ink-faint">{c.pendingText}</span> : null}
              </legend>
              <div className="flex flex-wrap gap-2">
                {options.map((v, i) => (
                  <label key={v} className="cursor-pointer">
                    <input type="radio" name={`item-${index}`} value={v} checked={draft[index] === v} onChange={() => setDraft({ ...draft, [index]: v })} className="peer sr-only" />
                    <span className="block rounded-ui border border-line-strong px-3 py-2 text-sm transition-colors peer-checked:border-accent-strong peer-checked:bg-accent-wash peer-focus-visible:outline-2 peer-focus-visible:outline-accent hover:border-ink">
                      {text?.options[i] ?? v}
                    </span>
                  </label>
                ))}
              </div>
            </fieldset>
          ))}
          {save.isError ? <Notice tone="attention" title={errorText(save.error)} /> : null}
          <div className="flex flex-wrap items-center gap-3">
            <Button type="submit" disabled={!ready} pending={save.isPending}>
              {c.save}
            </Button>
            <Button type="button" variant="ghost" onClick={onClose}>
              Seguir más tarde
            </Button>
          </div>
          {state.answered > 0 && !save.isPending ? <p className="text-step--1 text-ink-faint">{c.done}</p> : null}
        </form>
      )}

      {state.answered > 0 ? (
        <div className="border-t border-line pt-4">
          <Button
            variant="quiet"
            size="sm"
            pending={reset.isPending}
            onClick={() =>
              reset.mutate(undefined, {
                onSuccess: () => {
                  setState({ answered: 0, nextItems: firstItems(scale.code, scale.items) });
                  setDraft({});
                },
              })
            }
          >
            {c.restart}
          </Button>
        </div>
      ) : null}
    </div>
  );
}

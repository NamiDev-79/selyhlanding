import { facts } from "@/content/landing";

/** Cifras de diseño del producto, en una fila grande y fácil de escanear. */
export function Facts() {
  return (
    <section aria-label="Selyh en cifras" className="wrap py-[clamp(3rem,2rem+4vw,5.5rem)]">
      <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-[1.4rem] border border-line bg-line lg:grid-cols-4">
        {facts.map((f) => (
          <div key={f.label} className="reveal grid content-start gap-1 bg-paper p-6 sm:p-8">
            <dt className="order-2 text-sm text-ink-soft">{f.label}</dt>
            <dd className="order-1 flex items-baseline gap-2">
              <span className="font-display text-step-5 font-semibold leading-none tracking-tight">{f.value}</span>
              <span className="font-medium text-accent-strong">{f.unit}</span>
            </dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

"use client";

import { useQuery } from "@tanstack/react-query";

import { Button } from "@/components/ui/button";
import { Empty, Loading, Notice } from "@/components/ui/feedback";
import { interventionCopy } from "@/content/panel";
import { api, errorText, unwrap } from "@/lib/api/client";
import { CrisisResources } from "@/features/crisis/crisis-resources";

import { useFeedback, useLibrary, useNextSuggestion, useRespond, useSuggestionHistory } from "./hooks";

const c = interventionCopy;

/** Texto del ejercicio: párrafos simples (el contenido clínico es Markdown sencillo). */
function Body({ text }: { text: string }) {
  return (
    <div className="grid max-w-[60ch] gap-3">
      {text.split(/\n{2,}/).map((p, i) => (
        <p key={i}>{p.replace(/[*_#`]/g, "")}</p>
      ))}
    </div>
  );
}

function Actions({ id, response, feedback }: { id: string; response: string | null; feedback: string | null }) {
  const respond = useRespond();
  const rate = useFeedback();
  if (!response) {
    return (
      <div className="flex flex-wrap gap-2">
        {(["ACCEPTED", "POSTPONED", "DISMISSED"] as const).map((r) => (
          <Button key={r} size="sm" variant={r === "ACCEPTED" ? "primary" : "ghost"} pending={respond.isPending && respond.variables?.response === r} onClick={() => respond.mutate({ id, response: r })}>
            {c.respond[r]}
          </Button>
        ))}
      </div>
    );
  }
  if (response === "ACCEPTED" && !feedback) {
    return (
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-step--1 text-ink-soft">{c.feedbackQuestion}</span>
        {(["HELPFUL", "NOT_HELPFUL"] as const).map((f) => (
          <Button key={f} size="sm" variant="secondary" pending={rate.isPending && rate.variables?.feedback === f} onClick={() => rate.mutate({ id, feedback: f })}>
            {c.feedback[f]}
          </Button>
        ))}
      </div>
    );
  }
  return (
    <p className="text-step--1 text-ink-faint">
      {c.responded[response]}
      {feedback ? ` · ${c.feedback[feedback as "HELPFUL" | "NOT_HELPFUL"]}` : ""}
    </p>
  );
}

/** Pedir un ejercicio ahora (manual) y responderlo. Respeta tope diario y alertas de crisis. */
export function SuggestionNow() {
  const next = useNextSuggestion();
  const prefs = useQuery({ queryKey: ["preferences"], queryFn: () => unwrap(api.GET("/preferences")) });
  const history = useSuggestionHistory();
  const result = next.data;
  const current = result?.suggestion ? history.data?.find((h) => h.id === result.suggestion!.id) : undefined;

  return (
    <section className="grid gap-6">
      <div className="flex flex-wrap items-center gap-4">
        <Button onClick={() => next.mutate()} pending={next.isPending}>
          {c.ask}
        </Button>
        {prefs.data ? <span className="text-step--1 text-ink-faint">{c.cap(prefs.data.dailySuggestionCap)}</span> : null}
      </div>
      {next.isError ? <Notice tone="attention" title={errorText(next.error)} /> : null}
      {result && !result.suggestion ? (
        result.reason === "OPEN_CRISIS_FLAG" && result.resources ? (
          <CrisisResources resources={result.resources} lead={c.reasons.OPEN_CRISIS_FLAG} />
        ) : (
          <Notice tone="neutral" title={c.reasons[result.reason] ?? result.reason} />
        )
      ) : null}
      {result?.suggestion ? (
        <article className="grid gap-4 border-t border-ink pt-6">
          <p className="eyebrow">
            {c.category[result.suggestion.intervention.category] ?? result.suggestion.intervention.category} · {result.suggestion.intervention.durationMinutes} min
          </p>
          <h3 className="text-step-3">{result.suggestion.intervention.title}</h3>
          <Body text={result.suggestion.intervention.bodyMarkdown} />
          <Actions id={result.suggestion.id} response={current?.response ?? null} feedback={current?.feedback ?? null} />
        </article>
      ) : null}
    </section>
  );
}

export function SuggestionHistory() {
  const history = useSuggestionHistory();
  const library = useLibrary();
  if (history.isPending) return <Loading />;
  if (history.isError) return <Notice tone="attention" title={errorText(history.error)} />;
  if (!history.data.length) return <Empty title="Aún no hay sugerencias">Cuando tu carga suba o pidas un ejercicio, aparecerá aquí con lo que respondiste.</Empty>;

  const titles = new Map((library.data ?? []).map((i) => [i.id, i]));
  return (
    <ol className="grid border-t border-line">
      {history.data.map((s) => {
        const item = titles.get(s.interventionId);
        return (
          <li key={s.id} className="grid gap-2 border-b border-line py-4 sm:grid-cols-[8rem_1fr_auto] sm:items-baseline sm:gap-6">
            <span className="figures text-sm text-ink-faint">{new Date(s.suggestedAt).toLocaleDateString("es-PE", { day: "2-digit", month: "short" })}</span>
            <span>{item?.title ?? "Ejercicio"}</span>
            <Actions id={s.id} response={s.response} feedback={s.feedback} />
          </li>
        );
      })}
    </ol>
  );
}

export function Library() {
  const library = useLibrary();
  if (library.isPending) return <Loading />;
  if (library.isError) return <Notice tone="attention" title={errorText(library.error)} />;
  if (!library.data.length) return <Empty title="Biblioteca en preparación">Los ejercicios aparecen aquí cuando nuestra psicóloga los aprueba.</Empty>;
  return (
    <dl className="grid border-t border-line">
      {library.data.map((i) => (
        <details key={i.id} className="group border-b border-line py-4">
          <summary className="flex cursor-pointer list-none items-baseline justify-between gap-6">
            <dt className="font-medium group-open:text-accent-strong">{i.title}</dt>
            <span className="figures shrink-0 text-sm text-ink-faint">
              {c.category[i.category] ?? i.category} · {i.durationMinutes} min
            </span>
          </summary>
          <dd className="pt-3 text-ink-soft">
            <Body text={i.bodyMarkdown} />
          </dd>
        </details>
      ))}
    </dl>
  );
}

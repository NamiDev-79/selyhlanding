import { faq } from "@/content/faq";
import { plans } from "@/content/plans";
import { site } from "@/content/site";

/** Datos estructurados (schema.org) de la landing: Organization, SoftwareApplication y FAQPage. */
export function LandingJsonLd() {
  const graph = [
    {
      "@type": "Organization",
      "@id": `${site.url}/#organization`,
      name: site.name,
      url: site.url,
      email: site.email,
      address: { "@type": "PostalAddress", addressLocality: "Trujillo", addressCountry: "PE" },
    },
    {
      "@type": "SoftwareApplication",
      name: site.name,
      applicationCategory: "HealthApplication",
      operatingSystem: "Web, Windows, macOS, Linux, Android, iOS",
      description: site.description,
      publisher: { "@id": `${site.url}/#organization` },
      offers: plans.map((p) => ({ "@type": "Offer", name: p.name, price: p.price, priceCurrency: "USD" })),
    },
    {
      "@type": "FAQPage",
      mainEntity: faq.items.map((i) => ({ "@type": "Question", name: i.q, acceptedAnswer: { "@type": "Answer", text: i.a } })),
    },
  ];
  const json = JSON.stringify({ "@context": "https://schema.org", "@graph": graph }).replace(/</g, "\\u003c");
  return <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: json }} />;
}
